#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "midia.h"
#include "menu.h"
#include "album.h"
#include "usuario.h"
#include "playlist.h"

struct playlist
{
    char *nome;
    int qtdDonos;
    char *dono[2];
    int status;
    int qtdMidias;
    Midia *midias[50];
    int livrePlay;
    int seguir;
};

struct midia
{
    int tipoMidia; //1 musica, 2 video, 3 podcast;
    char *nomeDaMidia;
    char *nomeDoCantor;
    char *nomeDoCompositor;
    char *genero;
    char *gravadora;
    float duracaoMidia;
    char *artista;
    char *produtor;
};

char *LeNome()
{
    char *nome = (char *)malloc(200);
    setbuf(stdin, NULL);
    scanf("%[^\n]s", nome);
    setbuf(stdin, NULL);
    return nome;
}
float LeFloat()
{
    float dur;
    setbuf(stdin, NULL);
    scanf("%f", &dur);
    setbuf(stdin, NULL);
    return dur;
}
int LeInt()
{
    int n;
    setbuf(stdin, NULL);
    scanf("%d", &n);
    setbuf(stdin, NULL);
    return n;
}
void Musica(Midia *m, char *auxNome, char *auxCantor, char *auxCompositor, char *auxGenero, char *auxGravadora, float duracao)
{
    printf("Nome da musica: ");
    auxNome = LeNome();
    printf("Nome do Cantor: ");
    auxCantor = LeNome();
    printf("Nome do compositor: ");
    auxCompositor = LeNome();
    printf("Nome do Genero da musica: ");
    auxGenero = LeNome();
    printf("Nome da Gravadora: ");
    auxGravadora = LeNome();
    printf("Duracao da Musica: ");
    duracao = LeFloat();
    CriaMusica(m, auxNome, auxCantor, auxCompositor, auxGenero, auxGravadora, duracao);
}
void Video(Midia *m, char *auxNome, char *auxArtista, float duracao)
{
    printf("Nome do video: ");
    auxNome = LeNome();
    printf("Nome do Artista: ");
    auxArtista = LeNome();
    printf("Duracao do Video: ");
    duracao = LeFloat();
    CriaVideo(m, auxNome, auxArtista, duracao);
}
void Podcast(Midia *m, char *auxNome, char *auxProdutor, float duracao)
{
    printf("Nome do Podcast: ");
    auxNome = LeNome();
    printf("Nome do produtor do podcast: ");
    auxProdutor = LeNome();
    printf("Duracao do Podcast: ");
    duracao = LeFloat();
    CriaPodcast(m, auxNome, auxProdutor, duracao);
}
///Codigo 2

int main()
{
    Midia *m;
    Album *a[20];
    Usuario *u[3];
    Playlist *p[20];
    //Variaveis auxiliares para o funcionamento do gerenciador;
    char *auxNome = (char *)malloc(200);
    char *auxCantor = (char *)malloc(200);
    char *auxCompositor = (char *)malloc(200);
    char *auxArtista = (char *)malloc(200);
    char *auxProdutor = (char *)malloc(200);
    char *auxGenero = (char *)malloc(200);
    char *auxGravadora = (char *)malloc(200);
    float duracao;

    char *nomeUser = (char *)malloc(200);
    char *loginUser = (char *)malloc(200);
    char *senhaUser = (char *)malloc(200);
    int idadeUser, user = 0;

    char *nomePlay = (char *)malloc(200);
    char *donos = (char *)malloc(200);
    char *donosG = (char *)malloc(200);

    char *NomePesquisa = (char *)malloc(200);

    int opcao, auxQtdMidia, auxQtdAlbum = 0, indice = 0, j = 0, aux = 1, tipoMidia = 0, resp, iP = 0, qtdDonos = 0, qtdPlay = 0, indicePlay = 1;
    int qtdAlbum = 0, antigo = 0, indiceAlbum = 0, indiceMidia = 0, livre = 0, qtdMidiasAdd = 0, aux2, aux3, k = 1, cnd = 0, achei = 0;
    int qtdComp = 0, iM, indiceaux = 0, c = 1, indiceUser = 0, logou = 0, rtn = 0, incremento = 0, auxStatus = 0, playIndice = 0, ui = 0, indiceLogin = 0;
    int criou = 0, r = 0, usuarioAtual = 0, rtnLivre = 0, qtdMidias, AlbumInicial = 0, progresso = 0, v[10];

    //Definindo a senha do desenvolvedor;
    char *senhaSistema = (char *)malloc(200);
    char *confere = (char *)malloc(200);
    strcpy(senhaSistema, "rodrigo");
    //Colocando 3 albuns iniciais no gerenciador;
    FILE *album;
    FILE *album2;
    FILE *album3;
    FILE *playlist;
    FILE *usuarios;
    FILE *config;
    for (int i = 0; i < 10; i++)
    {
        v[i] = -1;
    }
    album = fopen("albuns.txt", "r");
    if (album == NULL)
    {
        printf("ERRO AO ABRIR O ARQUIVO\n");
    }
    else
    {
    }
    fscanf(album, "%d", &qtdMidias);
    a[0] = AlocaAlbumArquivo(album, qtdMidias);
    fclose(album);
    album2 = fopen("albuns2.txt", "r");
    if (album2 == NULL)
    {
        printf("ERRO AO ABRIR O ARQUIVO\n");
    }
    else
    {
    }
    fscanf(album2, "%d", &qtdMidias);
    a[1] = AlocaAlbumArquivo(album2, qtdMidias);
    fclose(album2);
    album3 = fopen("albuns3.txt", "r");
    if (album3 == NULL)
    {
        printf("ERRO AO ABRIR O ARQUIVO\n");
    }
    else
    {
    }
    fscanf(album3, "%d", &qtdMidias);
    a[2] = AlocaAlbumArquivo(album3, qtdMidias);
    fclose(album3);
    qtdAlbum = 3;
    AlbumInicial = 3;
    system("clear");
    printf("ALBUNS ADICIONADOS COM SUCESSO\n\n");
    //Instruções inciais do sistema;
    printf("Ja acessou o UFES MUSIC antes?\n");
    printf("[1].SIM     -       [2].NAO\n");
    scanf("%d", &progresso);
    if (progresso == 1)
    {
        printf("Acessando os progressos antigos\n");
        ///////CONFIG//////
        config = fopen("config.txt", "r");
        if (config == NULL)
        {
            printf("ERRO CONFIG\n");
        }
        fscanf(config, "%d", &qtdPlay);
        fclose(config);
        iP = qtdPlay;
        //USUARIOS/////
        config = fopen("config.txt", "r");
        fscanf(config, "%d", &qtdPlay);
        fclose(config);
        usuarios = fopen("usuarios.txt", "r");
        u[0] = LerUsuarioArquivo(usuarios, 1);
        u[1] = LerUsuarioArquivo(usuarios, 1);
        u[2] = LerUsuarioArquivo(usuarios, 1);
        indiceUser = 3;
        fclose(usuarios);
        ///PLAYLISTS//////
        playlist = fopen("playlist.txt", "r");
        if (playlist == NULL)
        {
            printf("ERRO AO ABRIR O ARQUIVO\n");
        }
        for (int h = 0; h < qtdPlay; h++)
        {
            p[h] = AlocaPlaylistArquivo();
            fscanf(playlist, "%s\n", p[h]->nome);
            fscanf(playlist, "%d\n", &p[h]->qtdDonos);
            if (p[h]->qtdDonos == 1)
            {
                fscanf(playlist, "%s\n", p[h]->dono[0]);
            }
            else if (p[h]->qtdDonos == 2)
            {
                fscanf(playlist, "%s\n", p[h]->dono[0]);
                fscanf(playlist, "%s\n", p[h]->dono[1]);
            }
            fscanf(playlist, "%d\n", &p[h]->status);
            fscanf(playlist, "%d\n", &p[h]->qtdMidias);
            fscanf(playlist, "%d\n", &p[h]->livrePlay);
            printf("%d\n", p[h]->livrePlay);
            for (int i = 0; i < p[h]->qtdMidias; i++)
            {
                fscanf(playlist, "%d\n", &p[h]->midias[i]->tipoMidia);
                if (p[h]->midias[i]->tipoMidia == 1)
                {
                    fscanf(playlist, "%s\n", p[h]->midias[i]->nomeDaMidia);
                    fscanf(playlist, "%s\n", p[h]->midias[i]->nomeDoCantor);
                    fscanf(playlist, "%s\n", p[h]->midias[i]->nomeDoCompositor);
                    fscanf(playlist, "%s\n", p[h]->midias[i]->gravadora);
                    fscanf(playlist, "%s\n", p[h]->midias[i]->genero);
                    fscanf(playlist, "%f\n", &p[h]->midias[i]->duracaoMidia);
                }
                else if (p[h]->midias[i]->tipoMidia == 2)
                {
                    fscanf(playlist, "%s\n", p[h]->midias[i]->nomeDaMidia);
                    fscanf(playlist, "%s\n", p[h]->midias[i]->produtor);
                    fscanf(playlist, "%f\n", &p[h]->midias[i]->duracaoMidia);
                }
                else if (p[h]->midias[i]->tipoMidia == 3)
                {
                    fscanf(playlist, "%s\n", p[h]->midias[i]->nomeDaMidia);
                    fscanf(playlist, "%s\n", p[h]->midias[i]->artista);
                    fscanf(playlist, "%f\n", &p[h]->midias[i]->duracaoMidia);
                }
            }
        }
        fclose(playlist);
        printf("\nAntes de sair salve seu progresso no gerenciador\n");
    }
    else
    {
        ImprimeInicio();
        scanf("%d", &c);
        //CRIO O USUARIO INCIAL;
        system("clear");
        printf("             -CADASTROS-     \n\n\n");
        c = 1;
        for (int i = 0; i < 3; i++)
        {
            u[indiceUser] = AlocaUsuario();
            criou = 1;
            printf("USUARIO[%d]\n\n", c++);
            printf("Nome completo do novo usuario: \n");
            nomeUser = LeNome();
            AtribuiNomeUsuario(u[indiceUser], nomeUser, indiceUser);
            printf("Login para acesso: ");
            loginUser = LeNome();
            AtribuiLoginUsuario(u[indiceUser], loginUser);
            printf("Escolha uma senha: ");
            senhaUser = LeNome();
            AtribuiSenhaUsuario(u[indiceUser], senhaUser);
            printf("NOVO USUARIO CRIADO COM SUCESSO\n\n");
            iniciaQtdPlay(u[indiceUser]);
            indiceUser++;
            system("clear");
        }
        //FACO LOGIN NO USUARIO INICIAL
        system("clear");
        printf("LOGIN NO SISTEMA\n");
        printf("Usuario : ");
        loginUser = LeNome();
        printf("senha : ");
        senhaUser = LeNome();
        for (int i = 0; i < indiceUser; i++)
        {
            rtn = FazerLogin(u[i], loginUser, senhaUser);
            if (rtn == 1 && ui == 0)
            {
                logou = 1;
                printf("LOGIN FEITO COM SUCESSO\n\n");
                printf("BEM VINDO, %s!\n\n", loginUser);
                ui = 1;
                indiceLogin = i;
            }
            if (rtn == 1)
            {
                logou = 1;
                continue;
            }
        }
        if (rtn == 0 && ui == 0)
        {
            printf("USUARIO OU SENHA INCORRETO\n\n");
        }
    }
    while (1)
    {
        ImprimeMenuPrincipalNovo();
        scanf("%d", &opcao);
        if (opcao == 1)
        { ///GERENCIADOR DE USUARIO///
            GerenciadorUsuarios();
            scanf("%d", &resp);
            if (resp == 1)
            { //CRIAR NOVO USUARIO
                if (indiceUser == 3)
                {
                    printf("MAXIMO NUMERO DE USUARIOS DA VERSÃO GRATUITA ATINGIDOS\n");
                    printf("PARA MAIS USUARIOS, ADIQUIRA A VERSÃO PREMIUM\n\n");
                    continue;
                }
                u[indiceUser] = AlocaUsuario();
                criou = 1;
                printf("Nome completo do novo usuario: ");
                nomeUser = LeNome();
                AtribuiNomeUsuario(u[indiceUser], nomeUser, indiceUser);
                printf("Login para acesso: ");
                loginUser = LeNome();
                AtribuiLoginUsuario(u[indiceUser], loginUser);
                printf("Escolha uma senha: ");
                senhaUser = LeNome();
                AtribuiSenhaUsuario(u[indiceUser], senhaUser);
                system("clear");
                printf("NOVO USUARIO CRIADO COM SUCESSO\n");
                ImprimeUsuario(u[indiceUser], incremento);
                iniciaQtdPlay(u[indiceUser]);
                indiceUser++;
            }
            else if (resp == 2)
            { //FAZER LOGIN
                if (criou == 0)
                {
                    printf("Nenhum usuario criado ainda\n");
                    continue;
                }
                printf("LOGIN NO SISTEMA\n");
                printf("Usuario : ");
                loginUser = LeNome();
                printf("senha : ");
                senhaUser = LeNome();
                for (int i = 0; i < indiceUser; i++)
                {
                    rtn = FazerLogin(u[i], loginUser, senhaUser);
                    if (rtn == 1 && ui == 0)
                    {
                        logou = 1;
                        printf("LOGIN FEITO COM SUCESSO\n\n");
                        ui = 1;
                        indiceLogin = i;
                        continue;
                    }
                    if (rtn == 1)
                    {
                        logou = 1;
                        printf("Ja esta logado\n");
                        continue;
                    }
                }
                if (rtn == 0 && ui == 0)
                {
                    printf("USUARIO OU SENHA INCORRETO\n\n");
                }
            }
            else if (resp == 3)
            { //MOSTRAR USUARIO REGISTRADOS
                c = 1;
                for (int d = 0; d < indiceUser; d++)
                {
                    printf("USUARIO [%d]\n", c++);
                    incremento = RetornaQtdPlay(u[d]);
                    ImprimeUsuario(u[d], incremento);
                    for (int i = 0; i < qtdPlay; i++)
                    {
                        for (int h = 0; h < 2; h++)
                        {
                            rtn = ComparaUsuario(u[d], p[i]->dono[h]);
                            if (rtn == 0)
                            {
                                ImprimeNomePlaylist(p[i]);
                            }
                        }
                    }
                    printf("\n");
                }
            }
            else if (resp == 4)
            { //TROCAR DE USUARIO
                printf("USUARIOS DO GERENCIADOR\n");
                c = 1;
                for (int i = 0; i < indiceUser; i++)
                {
                    printf("USUARIO [%d]\n", c++);
                    ImprimeNomeUsuario(u[i]);
                }
                printf("Escolha o indice do usuario que deseja acessar\n");
                scanf("%d", &r);
                r--;
                printf("Usuario : ");
                loginUser = LeNome();
                printf("senha : ");
                senhaUser = LeNome();
                rtn = FazerLogin(u[r], loginUser, senhaUser);
                if (rtn == 1)
                {
                    usuarioAtual = r;
                    printf("TROCA DE USUARIO\nBEM VINDO, %s\n", loginUser);
                    for (int i = 0; i < qtdPlay; i++)
                    {
                        InicializaSeguirPlay(p[i]);
                    }
                }
                else
                {
                    printf("Usuario ou senha incorreto\n");
                    continue;
                }
            }
            else if (resp == 5)
            { //MOSTRAR AS PLAYLISTS SEGUIDAS PELO USUARIO LOGADO
                for (int i = 0; i < qtdPlay; i++)
                {
                    rtn = RetornaSeguir(p[i]);
                    if (rtn == 1)
                    {
                        ImprimeNomePlaylist(p[i]);
                    }
                }
            }
            else if (resp == 6)
            { //VOLTAR AO MENU PRINCIPAL
                continue;
            }
        }
        else if (opcao == 2)
        { ///GERENCIADOR DE ALBUNS///
            GerenciadorAlbuns();
            scanf("%d", &resp);
            if (resp == 1)
            { //MOSTRAR ALBUNS ARMAZENADOS NO SISTEMA
                printf("\nALBUNS ARMAZENADOS NO SISTEMA\n\n");
                aux = 1;
                for (j = 0; j < qtdAlbum; j++)
                {
                    printf("ALBUM [%d]\n", aux++);
                    ImprimeAlbum(a[j]);
                }
            }
            else if (resp == 2)
            { //VOLTAR AO MENU PRINCIPAL
            }
            else
            {
                printf("Opcao invalida!\n");
            }
        }
        else if (opcao == 3)
        { ///GERENCIADOR DE PLAYLIST///
            GerenciadorPlaylists();
            scanf("%d", &resp);
            if (resp == 1)
            { //CRIAR PLAYLIST
                p[iP] = AlocaPlaylist();
                printf("Nome da playlist: ");
                nomePlay = LeNome();
                AtribuiNomePlaylis(p[iP], nomePlay);
                qtdDonos = RetornaQtdDonosPlay(p[iP]);
                c = 1;
                printf("Escolha os usuarios que serão donos da nova playlist\n");
                for (int i = 0; i < indiceUser; i++)
                {
                    printf("USUARIO [%d]\n", c++);
                    ImprimeNomeUsuario(u[i]);
                }
                for (int l = 0; l < qtdDonos; l++)
                {
                    scanf("%d", &c);
                    c--;
                    rtnLivre = RetornaPosicaoLivreUser(u[c]);
                    AtribuirPlaylistAoUsuario(u[c], p[iP], rtnLivre);
                    donos = RetornaLoginUser(u[c]);
                    AtribuiDonoPlaylist(p[iP], donos, l);
                    incrementalQtdPlay(u[c]);
                    IncrementaPosicaoLivreUser(u[c]);
                }
                printf("Defina o status da nova playlist\n");
                printf("[1] PUBLICA   -  [2] PRIVADA\n");
                auxStatus = LeInt();
                printf("STATUS DA PLAYLIST DEFINIDO COM SUCESSO\n");
                AtribuiStatusPlaylist(p[iP], auxStatus);
                InicializaLivrePlay(p[iP]);
                qtdPlay++; ///qtd de play no gerenciador
                iP++;
            }
            else if (resp == 2)
            { //ADICIONAR MIDIA A UMA PLAYLIST
                printf("Ola, vamos adicionar midias a sua playlist\n");
                printf("Vou Listar para você as playlists existentes no gerenciador\n\n");
                c = 1;
                for (int x = 0; x < qtdPlay; x++)
                {
                    printf("PLAYLIST[%d]\n", c++);
                    ImprimeNomePlaylist(p[x]);
                }
                printf("Escolha o indice da playlist que deseja adicionar uma midia: ");
                scanf("%d", &indicePlay);
                indicePlay--;
                if (indicePlay >= qtdPlay)
                {
                    printf("Opcao invalida\n");
                    continue;
                }
                printf("Agora eu vou listar os albuns existentes no gerenciador\n\n");
                c = 1;
                for (int x = 0; x < qtdAlbum; x++)
                {
                    printf("ALBUM [%d]\n", c++);
                    ImprimeAlbum(a[x]);
                }
                printf("Escolha o indice do album que contem a midia que voce deseja adicionar a sua playlist\n");
                scanf("%d", &indiceAlbum);
                indiceAlbum--;
                if (indiceAlbum >= qtdAlbum)
                {
                    printf("Opcao invalida\n");
                    continue;
                }
                printf("Quase la,agora preciso que você selecione a midia deste album que deseja adicionar a sua playlist\n");
                ImprimeAlbum(a[indiceAlbum]);
                scanf("%d", &indiceMidia);
                indiceMidia--;
                livre = RetornaPosicaoLivre(p[indicePlay]);
                AdicionaMidiaAPlaylist(a[indiceAlbum], p[indicePlay], indiceMidia, livre);
                qtdMidiasAdd++;
                ImprimePlaylist(p[indicePlay], qtdMidiasAdd);
            }
            else if (resp == 3)
            { //IMPRIMIR AS PLAYLISTS DO GERENCIADOR
                c = 1;
                for (int t = 0; t < iP; t++)
                {
                    printf("PLAYLIST [%d]\n\n", c++);
                    ImprimePlaylist(p[t], 0);
                }
            }
            else if (resp == 4)
            { //ORDENAR AS PLAYLISTS
                k = 1;
                for (int m = 0; m < qtdPlay; m++)
                {
                    printf("Indice Playlist[%d]\n", k++);
                    ImprimeNomePlaylist(p[m]);
                }
                printf("Escolha o indice da playlist\n");
                scanf("%d", &indiceaux);
                indiceaux--;
                ImprimePlaylist(p[indiceaux], qtdMidiasAdd);
                printf("Escolha as midias que deseja trocar de prosicao:\n");
                scanf("%d %d", &aux2, &aux3);
                aux2 = aux2 - 1;
                aux3 = aux3 - 1;
                TrocaMidiaPlaylist(p[indiceaux], aux2, aux3);
                ImprimePlaylist(p[indiceaux], qtdMidiasAdd);
            }
            else if (resp == 6)
            { //EXCLUIR MIDIAS DE UMA PLAYLIST
                printf("Playlists existentes no gerenciador\n");
                k = 1;
                for (int m = 0; m < qtdPlay; m++)
                {
                    printf("Indice Playlist[%d]\n", k++);
                    ImprimeNomePlaylist(p[m]);
                }
                printf("Escolha o indice da  playlist que deseja editar:\n");
                scanf("%d", &playIndice);
                playIndice--;
                ImprimePlaylist(p[playIndice], qtdMidiasAdd);
                printf("Agora escolha a midia dessa playlist que voce deseja apagar:\n");
                scanf("%d", &iM);
                iM--;
                DeletaMidiaPlaylist(p[playIndice], iM, qtdMidiasAdd);
                DecrementalLivrePlay(p[playIndice]);
                qtdMidiasAdd--;
                ImprimePlaylist(p[playIndice], qtdMidiasAdd);
            }
            else if (resp == 8)
            { //APAGAR PLAYLIST
                k = 1;
                for (int m = 0; m < qtdPlay; m++)
                {
                    printf("Indice Playlist[%d]\n", k++);
                    ImprimeNomePlaylist(p[m]);
                }
                printf("Escolha o indice da playlist que deseja apagar\n");
                scanf("%d", &k);
                k--;
                ApagaPlaylist(p[k], iP);
                iP--;
                printf("PLAYLIST APAGADA COM SUCESSO\n");
                qtdPlay--;
                ImprimeNomePlaylist(p[k]);
            }
            else if (resp == 9)
            { //VOLTAR AO MENU PRINCIPAL
                continue;
            }
            else if (resp == 7)
            { //SEGUIR ALGUMA PLAYLIST
                printf("Ao seguir uma playlist, ela se torna uma de suas playlists favoritas no gerenciador\n\n");
                printf("Entretanto, só é possivel seguir playlists com o status PUBLICO\n\n");
                printf("Vou listar as playlists do gerenciador que possuem o status PUBLICO\n\n");
                c = 1;
                j = 0;
                for (int i = 0; i < qtdPlay; i++)
                {
                    printf("PLAYLIST [%d]\n", c++);
                    rtn = RetornaStatusPlaylist(p[i]);
                    if (rtn == 1)
                    {
                        ImprimePlaylist(p[i], qtdMidiasAdd);
                    }
                    else
                    {
                        printf("PRIVADA\n");
                        v[j] = i;
                        j++;
                    }
                }
                printf("Escolha o indice da playlist que deseja seguir\n");
                scanf("%d", &indicePlay);
                indicePlay--;
                for (int i = 0; i < 10; i++)
                {
                    if (indicePlay == v[i])
                    {
                        printf("VOCE ESCOLHEU O INDICE DE UMA PLAYLIST PRIVADA\n");
                        printf("NAO FOI POSSIVEL SEGUIR\n");
                        c = 10;
                        continue;
                    }
                }
                if (c == 10)
                {
                    continue;
                }
                SeguirPlay(p[indicePlay]);
                printf("PLAYLIST SEGUIDA COM SUCESSO\n");
            }
            else if (resp == 5)
            { //EDITAR INFORMAÇÕES DE ALGUMA PLAYLIST
                printf("MODIFICAR PLAYLIST\n\n");
                printf("Vou listar para você as playlists existentes no gerenciador\n\n");
                c = 1;
                for (int i = 0; i < qtdPlay; i++)
                {
                    printf("PLAYLIST [%d]\n", c++);
                    ImprimePlaylist(p[i], qtdMidiasAdd);
                }
                printf("Escolha o indice da playlist que deseja modificar: ");
                scanf("%d", &playIndice);
                playIndice--;
                printf("Oque deseja modificar na playlist selecionada\n");
                ImprimePlaylist(p[playIndice], qtdMidiasAdd);
                printf("[1] Nome    [2] Donos  [3] Status\n");
                scanf("%d", &resp);
                if (resp == 1)
                {
                    printf("Digite o novo nome da playlist: ");
                    auxNome = LeNome();
                    AtribuiNomePlaylis(p[playIndice], auxNome);
                }
                else if (resp == 2)
                {
                    rtn = RetornaQtdDonosPlay(p[playIndice]);
                    for (int i = 0; i < rtn; i++)
                    {
                        ImprimeDonoPlay(p[playIndice], i);
                        printf("Deseja modificar este dono?\n [1]SIM  [2]NÃO\n");
                        scanf("%d", &opcao);
                        if (opcao == 1)
                        {
                            donos = LeNome();
                            AtribuiDonoPlaylist(p[playIndice], donos, i);
                        }
                        else if (opcao == 2)
                        {
                            continue;
                        }
                        else
                        {
                            printf("Opção invalida\n");
                        }
                    }
                }
                else if (resp == 3)
                {
                    printf("Modifica status da playlist:\n [1] PUBLICA    [2] PRIVADA\n");
                    scanf("%d", &opcao);
                    if (opcao == 1)
                    {
                        AtribuiStatusPlaylist(p[playIndice], 1);
                    }
                    else
                    {
                        AtribuiStatusPlaylist(p[playIndice], 2);
                    }
                }
                else
                {
                    printf("Opcao invalida\n");
                }
                printf("PLAYLIST MODIFICADA COM SUCESSO\n\n");
                ImprimePlaylist(p[playIndice], qtdMidiasAdd);
            }
            else
            {
                printf("Opcao invalida!\n");
            }
        }
        else if (opcao == 4)
        { ///BUSCAR MIDIAS NO GERENCIADOR///
            system("clear");
            ImprimeMenuPesquisa();
            scanf("%d", &resp);
            printf("Oque voce procura?\n");
            setbuf(stdin, NULL);
            scanf("%[^\n]s", NomePesquisa);
            if (resp == 1)
            {
                achei = 0;
                for (int i = 0; i < qtdAlbum; i++)
                {
                    cnd = BuscarMidiaPeloNomeDaMidia(a[i], NomePesquisa); //BUSCAR PELO NOME DA MIDIA
                    printf("\n");
                    if (cnd == 1)
                    {
                        achei++;
                    }
                }
                if (achei == 0)
                {
                    printf("Não encontrei essa midia no gerenciador\n\n");
                }
            }
            else if (resp == 2)
            { //BUSCAR PELO NOME DO ARTISTA
                achei = 0;
                for (int i = 0; i < qtdAlbum; i++)
                {
                    cnd = BuscarMidiaPeloNomeDoArtista(a[i], NomePesquisa);
                    printf("\n");
                    if (cnd == 1)
                    {
                        achei++;
                    }
                }
                if (achei == 0)
                {
                    printf("Não encontrei essa midia no gerenciador\n\n");
                }
            }
            else if (resp == 3)
            { //BUSCAR PELO NOME DO ALBUM
                achei = 0;
                for (int i = 0; i < qtdAlbum; i++)
                {
                    cnd = BuscarMidiaPeloNomeDoAlbum(a[i], NomePesquisa);
                    printf("\n");
                    if (cnd == 1)
                    {
                        achei++;
                    }
                }
                if (achei == 0)
                {
                    printf("Nao encontrei nenhum album com esse nome no gerenciador\n\n");
                }
            }
            else if (resp == 4)
            { //BUSCAR PELO NOME DO COMPOSITOR
                achei = 0;
                for (int i = 0; i < qtdAlbum; i++)
                {
                    cnd = BuscarMidiaPeloNomeDoCompositor(a[i], NomePesquisa);
                    if (cnd == 1)
                    {
                        achei++;
                    }
                }
                if (achei == 0)
                {
                    printf("Não encontrei essa midia no gerenciador\n\n");
                }
            }
            else if (resp == 5)
            { //BUSCAR PELO GENERO DA MIDIA
                achei = 0;
                for (int i = 0; i < qtdAlbum; i++)
                {
                    cnd = BuscarMidiaPeloGenero(a[i], NomePesquisa);
                    printf("\n");
                    if (cnd == 1)
                    {
                        achei++;
                    }
                }
                if (achei == 0)
                {
                    printf("Não encontrei midias desse genero no gerenciador\n\n");
                }
            }
            else if (resp == 6)
            { //BUSCAR PELO NOME DA GRAVADORA
                achei = 0;
                for (int i = 0; i < qtdAlbum; i++)
                {
                    cnd = BuscarMidiaPeloNomeDaGravadora(a[i], NomePesquisa);
                    printf("\n");
                    if (cnd == 1)
                    {
                        achei++;
                    }
                }
                if (achei == 0)
                {
                    printf("Não encontrei midias dessa gravadora no gerenciador\n\n");
                }
            }
            else
            { //opcao invalida, volta ao menu anterior
                system("clear");
                printf("Opcao invalida\n");
                continue;
            }
        }
        else if (opcao == 5)
        { ///MODO DESENVOLVEDOR/// ///SENHA DE ACESSO DEFINIDA NO INICIO DO CODIGO///
            GerenciadorModoDesenvolvedor();
            scanf("%d", &resp);
            if (resp == 1)
            { //ADICIONAR ALBUNS AO SISTEMA
                printf("Para acessar essa opcao preciso da senha do desenvolvedor\n");
                printf("Senha: ");
                confere = LeNome();
                if (strcmp(confere, senhaSistema) == 0)
                {
                    printf("BEM VINDO DESENVOLVEDOR\n");
                    printf("Quantos albuns deseja adicionar ao sistema? ");
                    antigo = auxQtdAlbum + AlbumInicial;
                    scanf("%d", &auxQtdAlbum);
                    qtdAlbum = antigo + auxQtdAlbum;
                    for (j = antigo; j < qtdAlbum; j++)
                    {
                        printf("CRIAR NOVO ALBUM\n");
                        a[j] = AlocaAlbum();
                        printf("Nome do Album: ");
                        auxNome = LeNome();
                        AtribuiNomeAlbum(a[j], auxNome);
                        printf("Quantos compositores este album possui? ");
                        scanf("%d", &qtdComp);
                        AtribuiQtdComp(a[j], qtdComp);
                        c = 1;
                        for (int q = 0; q < qtdComp; q++)
                        {
                            printf("Compositor [%d]: ", c++);
                            auxCompositor = LeNome();
                            AtribuiNomeCompositorAlbum(a[j], auxCompositor, q);
                        }
                        auxQtdMidia = RetornaQtdMidiasAlbum(a[j]);
                        printf("\nARMAZENANDO MIDIAS DO ALBUM\n");
                        indice = 0;
                        for (int i = 0; i < auxQtdMidia; i++)
                        {
                            printf("Escolha o tipo de midia a ser armazenado: \n");
                            printf("[1] Musica  [2] Video   [3] Podcast\n");
                            scanf("%d", &tipoMidia);
                            if (tipoMidia == 1)
                            { //MUSICA
                                m = AlocaMidia();
                                Musica(m, auxNome, auxCantor, auxCompositor, auxGenero, auxGravadora, duracao);
                                AdicionarMidiaAlbum(a[j], m, indice);
                                indice++;
                                printf("MIDIA ADICIONADA COM SUCESSO\n\n");
                            }
                            else if (tipoMidia == 2)
                            { //VIDEO
                                m = AlocaMidia();
                                Video(m, auxNome, auxArtista, duracao);
                                AdicionarMidiaAlbum(a[j], m, indice);
                                indice++;
                                printf("MIDIA ADICIONADA COM SUCESSO\n\n");
                            }
                            else if (tipoMidia == 3)
                            { //PODCAST
                                m = AlocaMidia();
                                Podcast(m, auxNome, auxProdutor, duracao);
                                AdicionarMidiaAlbum(a[j], m, indice);
                                indice++;
                                printf("MIDIA ADICIONADA COM SUCESSO\n\n");
                            }
                            else
                            {
                                printf("Opcao invalida!\n");
                                i--;
                            }
                        }

                        printf("ALBUM CRIADO COM SUCESSO\n");
                    }
                }
                else
                {
                    printf("Senha invalida\n");
                    continue;
                }
            }
            else if (resp == 2)
            { ///ADICIONAR PLAYLISTS AO SISTEMA DO PROPRIO GERENCIADOR
                printf("Para acessar essa opcao preciso da senha do desenvolvedor\n");
                printf("Senha: ");
                confere = LeNome();
                if (strcmp(confere, senhaSistema) == 0)
                {
                    p[iP] = AlocaPlaylist();
                    printf("Nome da playlist: ");
                    nomePlay = LeNome();
                    AtribuiNomePlaylis(p[iP], nomePlay);
                    qtdDonos = 1;
                    c = 1;
                    for (int l = 0; l < qtdDonos; l++)
                    {
                        strcpy(donosG, "gerenciador");
                        AtribuiDonoPlaylist(p[iP], donosG, l);
                    }
                    printf("\nStatus da playlisty [PUBLICA]\n\n");
                    auxStatus = 1;
                    AtribuiStatusPlaylist(p[iP], auxStatus);
                    InicializaLivrePlay(p[iP]);
                    printf("PLAYLIST CRIADA E ADICIONADA AO SISTEMA\n\n");
                    qtdPlay++; ///qtd de play no gerenciador
                    iP++;
                }
                else
                {
                    printf("Senha invalida\n");
                    continue;
                }
            }
            else if (resp == 3)
            { //VOLTAR AO MENU PRINCIPAL
                continue;
            }
        }
        else if (opcao == 6)
        {
            //ALTERANDO CONFIGURAÇOES DO GERENCIADOR
            config = fopen("config.txt", "w");
            fprintf(config, "%d", qtdPlay);
            fclose(config);
            playlist = SalvarPlaylist(p, qtdPlay);
            usuarios = SalvarUsuarios(u, indiceUser);
            printf("Obrigada por usar o UFES MUSIC\n");
            printf("Feito por: Maria Luiza Armini\n");
            break;
        }
        else
        {
            printf("Opcao invalida!\n");
            continue;
        }
    }
}