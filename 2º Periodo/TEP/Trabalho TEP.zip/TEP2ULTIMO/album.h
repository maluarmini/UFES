#ifndef ALBUM_
#define ALBUM_

typedef struct album Album;
typedef struct midia Midia;

/*Inicializa um album
* inputs: nenhum
* output: ponteiro para o album inicializado
* pre-condicao: nenhuma
* pos-condicao:album de retorno existe
*/
Album * AlocaAlbum();
/*Cria um Album
* inputs: ponteiro para o nome,compositores
qtd de midias do album e quantidades de compositores
* output: nenhum
* pre-condicao: os ponteiros serem validos
* pos-condicao: album atribuido com as informaçẽs
*/
void CriarAlbum(char *nome,char *compositores,int qtdMidia,int qtdCompositores);

/*Funcoes que atribuem informações a um album
* inputs: ponteiros
* output: nenhum
* pre-condicao: os ponteiros serem validos
* pos-condicao: album atribuido com as informaçẽs
*/
void AtribuiNomeAlbum(Album *a, char *nome);

void AtribuiNomeCompositorAlbum(Album *a,char *compositor,int indice);

void AtribuiQtdMidia(Album *a,int qtd);

void AtribuiQtdComp(Album *a,int qtd);


/*Adiciona midia Album
* inputs: ponteiro para album,um para midia e um inteiro
* output: nenhum
* pre-condicao: os ponteiros serem validos
* pos-condicao: album atribuido com as informaçẽs
* essa funcao é responsavel por fazer a atribuição de midias a um album
* o inteiro representa a posição de midia 'livre' do album 
*/
void AdicionarMidiaAlbum(Album *a,Midia *m,int i);


/*Funcoão que retorna a qtd de midia de um album
* inputs: ponteiros para o album
* output: inteiro qtd de midias do album
* pre-condicao: os ponteiros serem validos
* o retorno da função eh usado na main
*/
int RetornaQtdMidiasAlbum(Album *a);

/*Funcoão que retorna a qtd de compositores de um album
* inputs: ponteiros para o album
* output: inteiro qtd de compositores do album
* pre-condicao: os ponteiros serem validos
* o retorno da função eh usado na main
*/
int RetornaQtdCompositores(Album *a);

//Imprime um album com suas informações
void ImprimeAlbum(Album *a);

/*buscar midia no sistema pelo nome da midia
* inputs: ponteiro para Album, alem de um ponteiro para char
* que é a informação buscada
* output: retorna verdadeiro ou falso
* pre-condicao: os ponteiros serem validos
*/
int BuscarMidiaPeloNomeDaMidia(Album *a,char *nomeMidia);


/*buscar midia no sistema pelo nome do artista
* inputs: ponteiro para Album, alem de um ponteiro para char
* que é a informação buscada
* output: retorna verdadeiro ou falso
* pre-condicao: os ponteiros serem validos
*/
int BuscarMidiaPeloNomeDoArtista(Album *a,char *nomeArtista);


/*buscar midia no sistema pelo nome do album
* inputs: ponteiro para Album, alem de um ponteiro para char
* que é a informação buscada
* output: retorna verdadeiro ou falso
* pre-condicao: os ponteiros serem validos
*/
int BuscarMidiaPeloNomeDoAlbum(Album *a,char *nomeAlbum);


/*buscar midia no sistema pelo nome do compositor
* inputs: ponteiro para Album, alem de um ponteiro para char
* que é a informação buscada
* output: retorna verdadeiro ou falso
* pre-condicao: os ponteiros serem validos
*/
int BuscarMidiaPeloNomeDoCompositor(Album *a,char *nomeCompositor);


/*buscar midia no sistema pelo genero da midia
* inputs: ponteiro para Album, alem de um ponteiro para char
* que é a informação buscada
* output: retorna verdadeiro ou falso
* pre-condicao: os ponteiros serem validos
*/
int BuscarMidiaPeloGenero(Album *a,char *genero);


/*buscar midia no sistema pela gravadora da midia
* inputs: ponteiro para Album, alem de um ponteiro para char
* que é a informação buscada
* output: retorna verdadeiro ou falso
* pre-condicao: os ponteiros serem validos
*/
int BuscarMidiaPeloNomeDaGravadora(Album *a,char *gravadora);


/*Funcao que aloca e le um arquivo contendo 1 album
* inputs: ponteiro para um arquivo .txt e um inteiro
*que representa a qtd de midias deste album q sera lido 
* output: retorna um ponteiro para album;
* pre-condicao: o ponteiro ser valido e a qtd de midia devida do album em questão;
*/
Album * AlocaAlbumArquivo(FILE *album,int qtdMidia);

/*Funcoes que atribuem qtd de midia a um album
* inputs: ponteiro e um inteiro (quantidade de midia a ser atribuida)
* output: nenhum
* pre-condicao: o ponteiro ser valido
* pos-condicao: album atribuido com as informaçẽs
*/

void AtribuiQtdMidiaAlbum(Album *a,int qtd);

#endif