#include <stdio.h>
#include <stdlib.h>
#include "midia.h"

struct midia{
    int tipoMidia;//1 musica, 2 video, 3 podcast;
    char *nomeDaMidia;
    char *nomeDoCantor;
    char *nomeDoCompositor;
    char *genero;
    char *gravadora;
    float duracaoMidia;
    char *artista;
    char *produtor;
};
Midia * AlocaMidia(){
    Midia *m;
    m = (Midia*)malloc(sizeof(Midia));
    m->nomeDaMidia =(char*)malloc(200);
    m->nomeDoCantor= (char*)malloc(200);
    m->nomeDoCompositor= (char*)malloc(200);       
    m->genero = (char*)malloc(200);   
    m->gravadora= (char*)malloc(200);
    m->artista = (char*)malloc(200);
    m->produtor = (char*)malloc(200); 
    return m;    
}
Midia * LePodcastArquivo(FILE *arq){
    Midia *m;
    int fim;
    fscanf(arq,"%s",m->nomeDaMidia);
    fscanf(arq,"%s",m->artista);
    fscanf(arq,"%f",&m->duracaoMidia);
    m->tipoMidia = 3;
    return m;    
}
Midia * LeMusicaArquivo(FILE *arq){
    Midia *m;
    int fim;
    fscanf(arq,"%s",m->nomeDaMidia);
    fscanf(arq,"%s",m->nomeDoCantor);
    fscanf(arq,"%s",m->nomeDoCompositor);
    fscanf(arq,"%s",m->gravadora);
    fscanf(arq,"%s",m->genero);
    fscanf(arq,"%f",&m->duracaoMidia);
    m->tipoMidia = 1;
    return m;    
}
Midia * LeVideoArquivo(FILE *arq){
    Midia *m;
    int fim;
    fscanf(arq,"%s",m->nomeDaMidia);
    fscanf(arq,"%s",m->produtor);
    fscanf(arq,"%f",&m->duracaoMidia);
    m->tipoMidia = 2;
    return m;    
}
void CriaMusica(Midia *m,char *nomeMidia,char *cantor,char *compositor,char *genero,char *gravadora,float duracao){
    m->nomeDaMidia = nomeMidia;
    m->nomeDoCantor = cantor;
    m->nomeDoCompositor = compositor;
    m->genero = genero;
    m->gravadora = gravadora;
    m->duracaoMidia = duracao;
    m->tipoMidia=1;
}

void CriaVideo(Midia *m,char *nomeMidia,char *artista,float duracao){
    m->nomeDaMidia = nomeMidia;
    m->artista = artista;
    m->duracaoMidia = duracao;
     m->tipoMidia=2;
}
void CriaPodcast(Midia *m,char *nomeMidia,char *produtor,float duracao){
    m->nomeDaMidia = nomeMidia;
    m->artista = produtor;
    m->duracaoMidia = duracao;
     m->tipoMidia=3;
}

void ImprimeMusica(Midia *m){
    printf("Nome da musica: %s\n",m->nomeDaMidia);
    printf("Nome do Cantor: %s\n",m->nomeDoCantor);
    printf("Nome do Compositor: %s\n",m->nomeDoCompositor);
    printf("Nome da Gravadora: %s\n",m->gravadora);
    printf("Nome do Gênero: %s\n",m->genero);
    printf("Duração da musica: %.2f\n",m->duracaoMidia);
}
void ImprimeMusicaArquivo(FILE *playlist,Midia *m){
    fprintf(playlist,"%s\n",m->nomeDaMidia);
    fprintf(playlist,"%s\n",m->nomeDoCantor);
    fprintf(playlist,"%s\n",m->nomeDoCompositor);
    fprintf(playlist,"%s\n",m->gravadora);
    fprintf(playlist,"%s\n",m->genero);
    fprintf(playlist,"%.2f\n",m->duracaoMidia);
}

void ImprimeVideo(Midia *midia){
    printf("Nome do Vídeo: %s\n",midia->nomeDaMidia);
    printf("Nome do Produtor do Vídeo: %s\n",midia->produtor);
    printf("Duracao do Vídeo: %.2f\n\n",midia->duracaoMidia);
}
void ImprimeVideoArquivo(FILE *playlist,Midia *m){
    fprintf(playlist,"%s\n",m->nomeDaMidia);
    fprintf(playlist,"%s\n",m->produtor);
    fprintf(playlist,"%.2f\n\n",m->duracaoMidia);
}
void ImprimePodcast(Midia *midia){
    printf("Nome do PodCast: %s\n",midia->nomeDaMidia);
    printf("Nome do Artista do PodCast %s\n",midia->artista);
    printf("Duração do PodCast: %.2f\n\n",midia->duracaoMidia);
}
void ImprimePodcastArquivo(FILE *playlist,Midia *m){
    fprintf(playlist,"%s\n",m->nomeDaMidia);
    fprintf(playlist,"%s\n",m->artista);
    fprintf(playlist,"%.2f\n\n",m->duracaoMidia);
}
void AtribuiNomeMidia(Midia *m,char *nome){
    m->nomeDaMidia = nome;
}
void AtribuiNomeCantor(Midia *m,char *cantor){
    m->nomeDoCantor = cantor;
}
void AtribuiNomeCompositor(Midia *m,char *compositor){
    m->nomeDoCompositor = compositor;
}
void AtribuiNomeGenero(Midia *m,char *genero){
    m->genero = genero;
}
void AtribuiNomeGravadora(Midia *m,char *gravadora){
    m->gravadora = gravadora;
}
void AtribuiDuracaoMidia(Midia *m,float duracao){
    m->duracaoMidia = duracao;
}
void ModificaNomeMidia(Midia *m,char *nome){

}
void ModificaNomeCantor(Midia *m,char *cantor){
    m->nomeDoCantor = cantor;
}
void ModificaNomeCompositor(Midia *m,char *compositor){
    m->nomeDoCompositor = compositor;
}
void ModificaNomeGenero(Midia *m,char *genero){
    m->genero = genero;
}
void ModificaNomeGravadora(Midia *m,char *gravadora){
    m->gravadora = gravadora;
}
void ModificaDuracaoMidia(Midia *m,float duracao){
    m->duracaoMidia = duracao;
}

char * RetornaNomeMidia(Midia *m){return m->nomeDaMidia;}
char * RetornaNomeCantor(Midia *m){return m->nomeDoCantor;}
char * RetornaNomeCompoditor(Midia *m){return m->nomeDoCompositor;}
char * RetornaNomeGenero(Midia *m){return m->genero;}
char * RetornaNomeGravdora(Midia *m){return m->gravadora;}
float RetornaDuracaoMidia(Midia *m){return m->duracaoMidia;}
int RetornaTipoMidia(Midia *m){return m->tipoMidia;}
void ApagaMidia(Midia *m){
    if(m->tipoMidia==1){
    free(m->nomeDaMidia);
    free(m->nomeDoCantor);
    free(m->nomeDoCompositor);
    free(m->genero);
    free(m->gravadora);
    free(m);
    }else if(m->tipoMidia==1){
    free(m->nomeDaMidia);
    free(m->artista);
    }else if(m->tipoMidia==1){
    free(m->nomeDaMidia);
    free(m->produtor);
    }
}