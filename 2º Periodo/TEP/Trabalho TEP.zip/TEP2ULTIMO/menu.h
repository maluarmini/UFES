#ifndef MENU_
#define MENU_

//Funções responsaveis por imprimir as opções do gerenciador

void ImprimeMenuPrincipal();

void ImprimeMenuPrincipalNovo();

void ImprimeMenuPesquisa();

void ImprimeInicio();

void GerenciadorAlbuns();

void GerenciadorPlaylists();

void GerenciadorUsuarios();

void GerenciadorModoDesenvolvedor();


#endif