#include <stdio.h>
#include <stdlib.h>
#include "usuario.h"
#include "playlist.h"
#include <string.h>
#include "midia.h"

struct usuario{
    char *nome;
    char *login;
    char *senha;
    Playlist *playUser[3];
    Playlist *Favoritas;
    int idade;
    int qtdPlay;
    int livrePlayUser;
    int indice;
};

struct playlist{
    char *nome;
    int qtdDonos;
    char *dono[2];
    int status;
    int qtdMidias;
    Midia *midias[50];
    int livrePlay;
    int seguir;
};

Usuario * AlocaUsuario(){
    Usuario *u;
    u = (Usuario *)malloc(sizeof(Usuario));
    u->nome = (char *)malloc(200);
    u->login = (char *)malloc(200);
    u->senha = (char *)malloc(200);
    u->Favoritas = (Playlist *)malloc(sizeof(Playlist));
    for(int i=0;i<4;i++){
    u->playUser[i] = AlocaPlaylistUser();    
    }
    u->livrePlayUser=0;
    return u;
}
void CriaUsuario(Usuario *u,char *nome,char *login,char *senha){

}
int RetornaPosicaoLivreUser(Usuario *u){
    return u->livrePlayUser;
}
void IncrementaPosicaoLivreUser(Usuario *u){
    u->livrePlayUser++;
}
int RetornaQtdPlay(Usuario *u){
    return u->qtdPlay;
}
void iniciaQtdPlay(Usuario *u){
    u->qtdPlay=0;
}
void incrementalQtdPlay(Usuario *u){
    u->qtdPlay++;
}
void decrementalQtdPlay(Usuario *u){
    u->qtdPlay--;
}
void AtribuiNomeUsuario(Usuario *u,char *nome,int indice){
    u->nome = nome;
    u->indice = indice;
}

void AtribuiLoginUsuario(Usuario *u,char *login){
    u->login = login;
}

void AtribuiSenhaUsuario(Usuario *u,char *senha){
    u->senha = senha;
}
char * RetornaLoginUser(Usuario *u){
    return u->login;
}

void ImprimeUsuario(Usuario *u,int i){
     printf("Nome : %s\n",u->nome);
     printf("Login : %s\n",u->login);
     printf("Senha : *****\n");
    /* if(i==0){printf("O usuario ainda não possui playlists\n");}else{
         printf("Playlists do usuario\n");
     }
     
     for(int j=0;j<i;j++){
         ImprimeNomePlaylist(u->playUser[j]);
         printf("\n");
     }*/   
}
void ImprimeNomeUsuario(Usuario *u){
    printf("Login : %s\n",u->login);
}

void AtribuirPlaylistAoUsuario(Usuario *u,Playlist *p,int indicePlay){
    u->playUser[indicePlay] = p;
  //  u->qtdPlay++;    
}
void AtribuiFavoritosUsuario(Usuario *u,Playlist *p,int indicePlay){
    u->Favoritas= p;
}

int FazerLogin(Usuario *u,char *login,char *senha){
    char auxLogin[20];
    char auxSenha[20];
    int i=0,j=0;
    strcpy(auxLogin,login);
    strcpy(auxSenha,senha);
    if(strcmp(auxLogin,u->login)==0){
        if(strcmp(auxSenha,u->senha)==0){
            return 1;
        }else{
            return 0;
        }
    }else{
        return 0;
    }
    return 0;
}

FILE * SalvarUsuarios(Usuario *u[3],int qtdUser){
FILE *usuarios;
int rtn;
usuarios = fopen("usuarios.txt","w");
for(int i=0;i<qtdUser;i++){
    fprintf(usuarios,"%s\n",u[i]->nome);
    fprintf(usuarios,"%s\n",u[i]->login);
    fprintf(usuarios,"%s\n",u[i]->senha);
    fprintf(usuarios,"%d\n",u[i]->qtdPlay);
    /*for(int j=0;j<u[i]->qtdPlay;j++){
    fprintf(usuarios,"%s\n",u[i]->playUser[j]->nome);    
    }*/
    
   /* rtn = RetornaQtdPlay(u[i]);
    for(int j=0;j<rtn;j++){
    ImprimirPlaylistArquivo(usuarios,u[i]->playUser[j]);    
    }*/
}
fclose(usuarios);
}
Usuario * LerUsuarioArquivo(FILE * arq,int qtdUser){//le e retorna um usuario
    int rtn;
    Usuario *u;
    qtdUser=1;
    for(int i=0;i<qtdUser;i++){
        u = AlocaUsuario();
        fscanf(arq,"%[^\n]s",u->nome);
        fscanf(arq,"\n");
        fscanf(arq,"%[^\n]s",u->login);
        fscanf(arq,"\n");
        fscanf(arq,"%[^\n]s",u->senha);
        fscanf(arq,"\n");
        fscanf(arq,"%d\n",&u->qtdPlay);
    }
    return u;
}

int ComparaUsuario(Usuario *u,char *dono){
    int rtn=0;
    rtn = strcmp(u->login,dono);
    return rtn;
}
