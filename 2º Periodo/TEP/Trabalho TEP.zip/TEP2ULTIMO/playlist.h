#ifndef PLAYLIST_
#define PLAYLIST_

typedef struct playlist Playlist;

typedef struct midia Midia;

typedef struct album Album;

Playlist * AlocaPlaylist();

Playlist * AlocaPlaylistUser();

Playlist * AlocaPlaylistArquivo();

void CriaPlaylist(Playlist *p,char *nomePlay,int qtdDonos,char *donos);

void AdicionaMidiaAPlaylist(Album *a, Playlist *p,int indiceMidia,int indicePlay);

int RetornaQtdDonosPlay(Playlist *p);

void AtribuiNomePlaylis(Playlist *p,char *nome);

void AtribuiDonoPlaylist(Playlist *p,char *dono,int indice);
   
void ImprimePlaylist(Playlist *p,int qtdMidias);

void ImprimeNomePlaylist(Playlist *p);

void TrocaMidiaPlaylist(Playlist *p,int i1,int i2);

void DeletaMidiaPlaylist(Playlist *p,int id,int qtd);

void ApagaPlaylist(Playlist *p,int ip);

//void TrocaPlaylist(Playlist *p[10],int i1,int i2);

void AtribuiStatusPlaylist(Playlist *p,int status);

int RetornaPosicaoLivre(Playlist *p);

char * RetornaNomePlaylisy(Playlist *p);

int RetornaStatusPlaylist(Playlist *p);

void InicializaLivrePlay(Playlist *p);

void DecrementalLivrePlay(Playlist *p);

void IncrementalLivrePlay(Playlist *p);

void SeguirPlay(Playlist *p);

int RetornaSeguir(Playlist *p);

void InicializaSeguirPlay(Playlist *p);

void ImprimeDonoPlay(Playlist *p,int i);

FILE * SalvarPlaylist(Playlist *p[10],int qtdPlay);

void ImprimirPlaylistArquivo(FILE *usuarios,Playlist *p);

Playlist* LePlaylistsArquivo(FILE *playlists);

void ImprimePlaylistSemMidias(Playlist *p,int qtdMidias);

int RetornaQtdMidiaPlay(Playlist *p);

#endif