#include <stdio.h>
#include <stdlib.h>
#include "playlist.h"
#include "midia.h"

struct playlist{
    char *nome;
    int qtdDonos;
    char *dono[2];
    int status;
    int qtdMidias;
    Midia *midias[50];
    int livrePlay;
    int seguir;
};


struct midia{
    int tipoMidia;//1 musica, 2 video, 3 podcast;
    char *nomeDaMidia;
    char *nomeDoCantor;
    char *nomeDoCompositor;
    char *genero;
    char *gravadora;
    float duracaoMidia;
    char *artista;
    char *produtor;
};

struct album{
    char *nomeDoAlbum;
    Midia *midias[51];
    char *compositor;
    int qtdMidias;
    int qtdCompositores;
};

Playlist * AlocaPlaylist(){
    Playlist *p;
    p=(Playlist*)malloc(sizeof(Playlist));
    printf("Quantos donos tera essa playlist? ");
    scanf("%d",&p->qtdDonos);
    for(int i=0;i<p->qtdDonos;i++){
        p->dono[i] = malloc(sizeof(char)*2*50);
    }
    p->qtdMidias=0;
    p->livrePlay=0;
    for(int j=0;j<=50;j++){
        p->midias[j] = AlocaMidia();
      //  p->midias[j] = (Midia *)malloc(sizeof(Midia));
    }
    printf("PLAYLIST CRIADA COM SUCESSO\n");
    printf("ARMAZENEI UM ESPACO DE 50 MIDIAS NA NOVA PLAYLIST\n\n");
    return p;
}

Playlist * AlocaPlaylistUser(){
    Playlist *p;
    p=(Playlist*)malloc(sizeof(Playlist));
    for(int i=0;i<2;i++){
        p->dono[i] = malloc(sizeof(char)*2*50);
    }
    p->qtdMidias=0;
    p->livrePlay=0;
    for(int j=0;j<=4;j++){
        p->midias[j] = AlocaMidia();
      //  p->midias[j] = (Midia *)malloc(sizeof(Midia));
    }
    return p;
}
int RetornaPosicaoLivre(Playlist *p){
    return p->livrePlay;
}
void AtribuiNomePlaylis(Playlist *p,char *nome){
    p->nome = nome;
}
void AtribuiDonoPlaylist(Playlist *p,char *dono,int indice){
    p->dono[indice] = dono;
}

void AtribuiStatusPlaylist(Playlist *p,int status){
    p->status = status;
}
int RetornaStatusPlaylist(Playlist *p){
    return p->status;
}
int RetornaQtdDonosPlay(Playlist *p){
    return p->qtdDonos;
}
void SeguirPlay(Playlist *p){
    p->seguir=1;
}
int RetornaQtdMidiaPlay(Playlist *p){
    return p->qtdMidias;
}
int RetornaSeguir(Playlist *p){
return p->seguir;
}

void InicializaSeguirPlay(Playlist *p){
    p->seguir=0;
}
char * RetornaNomePlaylisy(Playlist *p){
    return p->nome;
}
void ImprimePlaylist(Playlist *p,int qtdMidias){
   int indice=1;
    printf("Nome : %s\n",p->nome);
    for(int i=0;i<p->qtdDonos;i++){
        printf("Dono [%d]: %s\n",indice++,p->dono[i]);
        
    }
    printf("Midias dessa Playlist: \n\n");
    indice=1;
    for(int i=0;i<p->qtdMidias;i++){
        printf("MIDIA [%d]\n",indice++);
        if(p->midias[i]->tipoMidia==1){
            ImprimeMusica(p->midias[i]);
        }else if(p->midias[i]->tipoMidia==2){
            ImprimeVideo(p->midias[i]);
        }else if(p->midias[i]->tipoMidia==3){
            ImprimePodcast(p->midias[i]);
        }
        printf("\n");
    }
}
void ImprimePlaylistSemMidias(Playlist *p,int qtdMidias){
   int indice=1;
    printf("Nome : %s\n",p->nome);
    for(int i=0;i<p->qtdDonos;i++){
        printf("Dono [%d]: %s\n",indice++,p->dono[i]);
        
    }
}
void AdicionaMidiaAPlaylist(Album *a,Playlist *p,int indiceMidia,int indicePlay){
    p->midias[indicePlay] = a->midias[indiceMidia];
    p->qtdMidias++;
    p->livrePlay++;
    printf("Midia Adicionada com sucesso\n\n");
}

void ImprimeNomePlaylist(Playlist *p){
    if(p->nome)
    printf("Nome : %s\n",p->nome);
}

void DeletaMidiaPlaylist(Playlist *p,int id,int qtd){
    p->midias[51] = p->midias[id];
    for(int i=id;i<p->qtdMidias;i++){
        TrocaMidiaPlaylist(p,i,i+1);//subindo as midias na playlist
    }
    ApagaMidia(p->midias[51]);
    p->qtdMidias--;
    printf("\nMIDIA EXLUIDA COM SUCESSO\n\n");
}

void ApagaPlaylist(Playlist *p,int ip){
    free(p->nome);
    p->nome='\0';
  /*  for(int i=0;i<ip;i++){
    TrocaPlaylist(p,i,i+1); 
    }*/
    for(int i=0;i<p->qtdDonos;i++){
    free(p->dono[i]);
    }
    for(int i=0;i<p->qtdMidias;i++){
    DeletaMidiaPlaylist(p,i,0);    
    }
}
/*void TrocaPlaylist(Playlist *p,int i1,int i2){
    Playlist *aux;
    aux = (Playlist *)malloc(sizeof(Playlist));
    aux = p[i1];
    p[i1] = p[i2];
    p[i2] = aux;
}*/


void TrocaMidiaPlaylist(Playlist *p,int i1,int i2){
    Midia *aux;
    aux = (Midia *)malloc(sizeof(Midia));
    aux = p->midias[i1];
    p->midias[i1] = p->midias[i2];
    p->midias[i2] = aux;
}

void InicializaLivrePlay(Playlist *p){
    p->livrePlay = 0;
}
void DecrementalLivrePlay(Playlist *p){
    p->livrePlay--;
}
void IncrementalLivrePlay(Playlist *p){
    p->livrePlay++;
}
void ImprimeDonoPlay(Playlist *p,int i){
    printf("%s\n",p->dono[i]);
}

FILE * SalvarPlaylist(Playlist *p[10],int qtdPlay){
    int rtn;
    FILE *playlist;
    playlist = fopen("playlist.txt","w");
    for(int i=0;i<qtdPlay;i++){
        fprintf(playlist,"%s\n",p[i]->nome);
        rtn = RetornaQtdDonosPlay(p[i]);
        fprintf(playlist,"%d\n",p[i]->qtdDonos);
        for(int j=0;j<rtn;j++){
        fprintf(playlist,"%s\n",p[i]->dono[j]);
        }
        rtn = RetornaStatusPlaylist(p[i]);
        fprintf(playlist,"%d\n",rtn);//PUBLICA OU PRIVADA
        fprintf(playlist,"%d\n",p[i]->qtdMidias);
        fprintf(playlist,"%d\n",p[i]->livrePlay);
        for(int k=0;k<p[i]->qtdMidias;k++){
        rtn = RetornaTipoMidia(p[i]->midias[k]);
        fprintf(playlist,"%d\n",rtn);//TIPO
        if(rtn==1){
        ImprimeMusicaArquivo(playlist,p[i]->midias[k]);
        }else if(rtn==2){
        ImprimeVideoArquivo(playlist,p[i]->midias[k]);    
        }else if(rtn==3){
        ImprimePodcastArquivo(playlist,p[i]->midias[k]);    
        }    
        }
    }
    fclose(playlist);
}
void ImprimirPlaylistArquivo(FILE *usuarios,Playlist *p){
   int rtn;
    fprintf(usuarios,"%s\n",p->nome);
        rtn = RetornaQtdDonosPlay(p);
        for(int j=0;j<rtn;j++){
        fprintf(usuarios,"%s\n",p->dono[j]);
        }
        rtn = RetornaStatusPlaylist(p);
        fprintf(usuarios,"%d\n",rtn);//PUBLICA OU PRIVADA
        
        for(int k=0;k<p->qtdMidias;k++){
        rtn = RetornaTipoMidia(p->midias[k]);
        fprintf(usuarios,"%d\n",rtn);//TIPO
        if(rtn==1){
        ImprimeMusicaArquivo(usuarios,p->midias[k]);
        }else if(rtn==2){
        ImprimeVideoArquivo(usuarios,p->midias[k]);    
        }else if(rtn==3){
        ImprimePodcastArquivo(usuarios,p->midias[k]);    
        }    
}
}


Playlist * AlocaPlaylistArquivo(FILE *playlist){
    int tipo;
    Playlist *p = (Playlist *)malloc(sizeof(Playlist));
    p->nome = (char *)malloc(200);
    p->dono[0] = (char *)malloc(200);
    p->dono[1] = (char *)malloc(200);
  
    printf("TO aquiiiiiiii\n");
    for(int i=0;i<=50;i++){
        p->midias[i] = AlocaMidia();
    }
    return p;
}