#include <stdio.h>
#include <stdlib.h>
#include "album.h"
#include "midia.h"
#include <ctype.h>
#include <string.h>

struct album{
    char *nomeDoAlbum;
    Midia *midias[51];
    char *compositor[3];
    int qtdMidias;
    int qtdCompositores;
};
struct midia{
    int tipoMidia;//1 musica, 2 video, 3 podcast;
    char *nomeDaMidia;
    char *nomeDoCantor;
    char *nomeDoCompositor;
    char *genero;
    char *gravadora;
    float duracaoMidia;
    char *artista;
    char *produtor;
};

Album * AlocaAlbum(){
    int qtdMidia=0;
    Album *a = (Album *)malloc(sizeof(Album));
    a->nomeDoAlbum = (char *)malloc(sizeof(char)*50);
    printf("Qtd de midias no album: ");
    scanf("%d",&a->qtdMidias);
    for(int i=0;i<a->qtdMidias;i++){
        a->midias[i]=(Midia *)malloc(sizeof(Midia *));
    }
    for(int i=0;i<3;i++){
        a->compositor[i] = (char *)malloc(sizeof(50)*3);

    }
    setbuf(stdin,NULL);
    return a; 
}
Album * AlocaAlbumArquivo(FILE *album,int qtdMidia){
    int tipo;
    Album *a = (Album *)malloc(sizeof(Album));
    a->nomeDoAlbum = (char *)malloc(200);
    fscanf(album,"%s",a->nomeDoAlbum);
    setbuf(stdin,NULL);
    fscanf(album,"%d",&a->qtdCompositores);
    setbuf(stdin,NULL);
    for(int i=0;i<a->qtdCompositores;i++){
        a->compositor[i] = (char *)malloc(200);
    }
    for(int i=0;i<a->qtdCompositores;i++){
    fscanf(album,"%s",a->compositor[i]);
    setbuf(stdin,NULL);
    }
    AtribuiQtdMidiaAlbum(a,qtdMidia);
    for(int i=0;i<qtdMidia;i++){
        a->midias[i] = AlocaMidia();
        fscanf(album,"%d",&tipo);
        if(tipo==1){
        a->midias[i] = LeMusicaArquivo(album);    
        }else if(tipo==2){
        a->midias[i] = LeVideoArquivo(album);    
        }else if(tipo==3){
        a->midias[i] = LePodcastArquivo(album);    
        }
    }
    return a;
}
void AdicionarMidiaAlbum(Album *a,Midia *m,int i){
    a->midias[i]=m;
}
int RetornaQtdMidiasAlbum(Album *a){
    return a->qtdMidias;
}
void AtribuiNomeAlbum(Album *a, char *nome){
    a->nomeDoAlbum = nome;
}
void AtribuiNomeCompositorAlbum(Album *a,char *compositor,int indice){
    a->compositor[indice] = compositor;
}
void AtribuiMidiaAlbum(Album *a,Midia *m,int livre){
    a->midias[livre] = m;
}
void AtribuiQtdComp(Album *a,int qtd){
    a->qtdCompositores = qtd;
}

void ImprimeAlbum(Album *a){
int aux=1;    
printf("\n->INFORMACOES SOBRE O ALBUM\n\n");
printf("Nome : %s\n",a->nomeDoAlbum);
for(int i=0;i<a->qtdCompositores;i++){
printf("Compositor : %s\n",a->compositor[i]);
}
printf("MIDIAS DO ALBUM\n\n");
aux=1;
for(int i=0;i<a->qtdMidias;i++){
    printf("MIDIA [%d]\n",aux++);
    if(a->midias[i]->tipoMidia==1){
         ImprimeMusica(a->midias[i]);
    }else if(a->midias[i]->tipoMidia==2){
        ImprimeVideo(a->midias[i]);
    }else if(a->midias[i]->tipoMidia==3){
         ImprimePodcast(a->midias[i]);
    }
}

}

int BuscarMidiaPeloNomeDaMidia(Album *a,char *nomeMidia){//procura pelo nome da midia na vdd
    char aux[20];
    char aux2[20];
    int igual=0,tam1=0,tam2=0,cnd=0;
        for(int i = 0;i<a->qtdMidias;i++){
         strcpy(aux,a->midias[i]->nomeDaMidia);
         strcpy(aux2,nomeMidia);
         tam1 = strlen(aux);
         tam2 = strlen(aux2);
         for(int j =0;j<tam1;j++){
             aux[j] = toupper(aux[j]);
         }
         for(int t = 0;t<tam2;t++){
             aux2[t] = toupper(aux2[t]);
         }
         if(strstr(aux,aux2) != NULL) {
        printf("\nACHEI A MIDIA BUSCADA NESSE ALBUM\n");
        ImprimeAlbum(a);
        cnd = 1;
        break;
        }else{
            continue;
        }
}
    return cnd;
 }

 int BuscarMidiaPeloNomeDoArtista(Album *a,char *nomeArtista){
        char auxCantor[20];
        char auxArtista[20];
        char auxProdutor[20];
        char aux2[20];
        int tamCantor=0,tamArtista=0,tamProdutor=0,tam2=0,cnd=0;
        for(int i=0;i<a->qtdMidias;i++){
            strcpy(auxCantor,a->midias[i]->nomeDoCantor);
            strcpy(auxArtista,a->midias[i]->artista);
            strcpy(auxProdutor,a->midias[i]->produtor);
            strcpy(aux2,nomeArtista);
            tamCantor = strlen(auxCantor);
            tamArtista = strlen(auxArtista);
            tamProdutor = strlen(auxProdutor);
            tam2 = strlen(aux2);
            for(int j =0;j<tamCantor;j++){
             auxCantor[j] = toupper(auxCantor[j]);
         }
            for(int j =0;j<tamArtista;j++){
             auxArtista[j] = toupper(auxArtista[j]);
         }
            for(int j =0;j<tamProdutor;j++){
             auxProdutor[j] = toupper(auxProdutor[j]);
         }

         for(int t = 0;t<tam2;t++){
             aux2[t] = toupper(aux2[t]);
         }
         if(strstr(auxCantor,aux2) != NULL||strstr(auxArtista,aux2) != NULL||strstr(auxProdutor,aux2) != NULL) {
            printf("\nENCONTREI ESSE ARTISTA NESTE ALBUM\n");
            ImprimeAlbum(a);
            cnd = 1;
            break;
        }else{
            continue;
        }
        }
        return cnd;
 }

//Imprimir os albuns q o nome do artista aparece;
int BuscarMidiaPeloNomeDoAlbum(Album *a,char *nomeAlbum){
    char aux[20];
    char aux2[20];
    int tam1=0,tam2=0,cnd=0;
    strcpy(aux,a->nomeDoAlbum);
    strcpy(aux2,nomeAlbum);
    tam1 = strlen(aux);
    tam2 = strlen(aux2);
    for(int j =0;j<tam1;j++){
        aux[j] = toupper(aux[j]);
    }
    for(int t = 0;t<tam2;t++){
        aux2[t] = toupper(aux2[t]);
    }
    if(strstr(aux,aux2) != NULL){
        printf("ENCONTREI UM ALBUM COM ESTE NOME\n");
        ImprimeAlbum(a);
        cnd=1;
    }
    return cnd;
}
//Imprimir os albuns q o nome do album foi encontrado;
int BuscarMidiaPeloNomeDoCompositor(Album *a,char *nomeCompositor){
        char aux[20];
        char aux2[20];
        int tam1=0,tam2=0,cnd=0;
        for(int i=0;i<a->qtdCompositores;i++){
            strcpy(aux,a->compositor[i]);
            strcpy(aux2,nomeCompositor);
            tam1 = strlen(aux);
            tam2 = strlen(aux2);
            for(int j =0;j<tam1;j++){
             aux[j] = toupper(aux[j]);
         }
         for(int t = 0;t<tam2;t++){
             aux2[t] = toupper(aux2[t]);
         }
         if(strstr(aux,aux2) != NULL) {
            printf("\nENCONTREI ESSE COMPOSITOR NESTE ALBUM\n");
            ImprimeAlbum(a);
            cnd = 1;
            break;
        }else{
            continue;
        }
        }
        return cnd;
}
//Imprimir os albuns q o nome do compositor aparece;

int BuscarMidiaPeloGenero(Album *a,char *genero){
   char aux[20];
    char aux2[20];
    int igual=0,tam1=0,tam2=0,cnd=0;
        for(int i = 0;i<a->qtdMidias;i++){
         strcpy(aux,a->midias[i]->genero);
         strcpy(aux2,genero);
         tam1 = strlen(aux);
         tam2 = strlen(aux2);
         for(int j =0;j<tam1;j++){
             aux[j] = toupper(aux[j]);
         }
         for(int t = 0;t<tam2;t++){
             aux2[t] = toupper(aux2[t]);
         }
         if(strstr(aux,aux2) != NULL) {
        printf("\nACHEI MIDIAS COM ESSE GENERO NESSE ALBUM\n");
        ImprimeAlbum(a);
        cnd = 1;
        break;
        }else{
            continue;
        }
}
    return cnd;
}
//Imprimir os albuns q o genero foi encontrado;
int BuscarMidiaPeloNomeDaGravadora(Album *a,char *gravadora){
    char aux[20];
    char aux2[20];
    int igual=0,tam1=0,tam2=0,cnd=0;
        for(int i = 0;i<a->qtdMidias;i++){
         strcpy(aux,a->midias[i]->gravadora);
         strcpy(aux2,gravadora);
         tam1 = strlen(aux);
         tam2 = strlen(aux2);
         for(int j =0;j<tam1;j++){
             aux[j] = toupper(aux[j]);
         }
         for(int t = 0;t<tam2;t++){
             aux2[t] = toupper(aux2[t]);
         }
         if(strstr(aux,aux2) != NULL) {
        printf("\nACHEI MIDIAS DESSA GRAVADORA NESSE ALBUM\n");
        ImprimeAlbum(a);
        cnd = 1;
        break;
        }else{
            continue;
        }
}
    return cnd;
}
void AtribuiQtdMidiaAlbum(Album *a,int qtd){
    a->qtdMidias = qtd;
}
//Imprimir os albuns q o nome da gravadora aparece;
