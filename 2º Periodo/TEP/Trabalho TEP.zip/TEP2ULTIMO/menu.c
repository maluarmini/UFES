#include <stdio.h>
#include <stdlib.h>
#include "menu.h"


void ImprimeInicio(){
    printf("|--------BEM VINDO AO UFES MUSIC------ |\n");
    printf("|-PARA COMEÇAR...                      |\n");
    printf("|-Crie três NOVOS USUÁRIOS             |\n");
    printf("|-Faça LOGIN em um usuario             |\n");
    printf("|PRESSIONE '1' PRA PROSSEGUIR          |\n");  
}


void ImprimeMenuPrincipalNovo(){
   // system("clear");
    printf("|--------------------------------------|\n");
    printf("|---------------UFES MUSIC-------------|\n");
    printf("|--------------------------------------|\n");
    printf("|1.Gerenciador de Usuario              |\n");
    printf("|   -Criar novo Usuario                |\n");
    printf("|   -Fazer login                       |\n");
    printf("|   -Mostrar Usuarios                  |\n");
    printf("|   -Trocar de Usuario                 |\n");
    printf("|   -Mostrar playlists seguidas        |\n");

    printf("|2.Gerenciador de Albuns               |\n");
    printf("|   -Mostrar Albuns existentes         |\n");

    printf("|3.Gerenciador de Playlists            |\n");
    printf("|   -Criar nova Playlist               |\n");
    printf("|   -Adicionar midias a Playlist       |\n");
    printf("|   -Imprimir Playlists do gerenciador |\n");
    printf("|   -Ordenar Playlist                  |\n");
    printf("|   -Editar informações de uma Playlist|\n");
    printf("|   -Excluir midia da Playlist         |\n");
    printf("|   -Seguir Playlist                   |\n");
    printf("|   -Apagar playlist                   |\n");

    printf("|4.Buscar Midias no gerenciador        |\n");
    
    printf("|5.Modo desenvolvedor                  |\n");
    printf("|   -Adiciona albuns                   |\n");
    printf("|   -Criar Playlists do sistema        |\n");

    printf("|6.Sair do gerenciador                 |\n");
}
void GerenciadorAlbuns(){
    system("clear");
    printf("GERENCIADOR DE ALBUNS                 \n\n");
    printf("1.Mostrar Albuns existentes           \n");
    printf("2.Voltar ao menu principal            \n");
}

void GerenciadorPlaylists(){
    system("clear");
    printf("GERENCIADOR DE PLAYLISTS              \n\n");
    printf("1.Criar nova Playlist                 \n");
    printf("2.Adicionar midia a Playlist          \n");
    printf("3.Imprimir Playlists do gerenciador   \n");
    printf("4.Ordenar midias na Playlist          \n");
    printf("5.Editar informações de uma Playlist  \n");
    printf("6.Excluir midias da Playlist          \n");
    printf("7.Seguir Playlist                     \n");
    printf("8.Apagar Playlist                     \n");
    printf("9.Voltar ao menu principal            \n");
}

void GerenciadorUsuarios(){
    system("clear");
    printf("GERENCIADOR DE USUARIOS              \n\n");
    printf("1.Criar novo Usuario                 \n");
    printf("2.Fazer Login                         \n");
    printf("3.Mostrar usuarios                    \n");
    printf("4.Trocar de usuario                   \n");
    printf("5.Mostrar Playlists seguidas pelo usuario LOGADO\n");
    printf("6.Voltar ao menu principal            \n");
}
void GerenciadorModoDesenvolvedor(){
    system("clear");
    printf("GERENCIADOR DE DESENVOLVEDOR         \n\n");
    printf("1.Adicionar albuns                   \n");
    printf("2.Criar playlists do sistema          \n");
    printf("3.Voltar ao menu principal            \n");
}
void ImprimeMenuPesquisa(){
    printf("Deseja buscar sua midia atraves do:\n");
    printf("1.Nome da midia\n2.Nome do artista\n3.Nome do album\n4.Nome do compositor\n5.Genero\n6.Gravadora\n");
}

