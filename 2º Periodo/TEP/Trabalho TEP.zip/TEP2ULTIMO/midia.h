#ifndef MIDIA_
#define MIDIA_

typedef struct midia Midia;

/*Inicializa uma midia
* inputs: nenhum
* output: ponteiro para a midia inicializada
* pre-condicao: nenhuma
* pos-condicao:midia de retorno existe
*/
Midia * AlocaMidia();

/*Cria musica
* inputs: Ponteiro para midia,ponteiros de char para nome,cantor,compositor,genero,gravadora e um float duracao
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void CriaMusica(Midia *m,char *nomeMidia,char *cantor,char *compositor,char *genero,char *gravadora,float duracao);
/*Cria video
* inputs: Ponteiro para midia,ponteiros de char para nome,produtor e float duracao
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void CriaVideo(Midia *m,char *nomeMidia,char *produtor,float duracao);
/*Cria Podcast
* inputs: Ponteiro para midia,ponteiros de char para nome,artista e um float duracao
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void CriaPodcast(Midia *m,char *nomeMidia,char *artista,float duracao);

/*Atribui/modifica um nome a midia
* inputs: Ponteiro para midia,ponteiros de char para nome
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: modifica nome da midia
*/
void AtribuiNomeMidia(Midia *m,char *nome);
/*Atribui/modifica um cantor a midia
* inputs: Ponteiro para midia,ponteiros de char para o cantor
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: modifica o cantor da midia
*/
void AtribuiNomeCantor(Midia *m,char *cantor);
/*Atribui/modifica um cantor a midia
* inputs: Ponteiro para midia,ponteiros de char para o compositor
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: modifica o compositor da midia
*/
void AtribuiNomeCompositor(Midia *m,char *compositor);

/*Atribui/modifica um genero a midia
* inputs: Ponteiro para midia,ponteiros de char para o genero
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: modifica o genero da midia
*/
void AtribuiNomeGenero(Midia *m,char *genero);
/*Atribui/modifica uma gravadora a midia
* inputs: Ponteiro para midia,ponteiros de char para a gravadora
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: modifica a gravadora da midia
*/
void AtribuiNomeGravadora(Midia *m,char *gravadora);
/*Atribui/modifica duracao a midia
* inputs: Ponteiro para midia e um float duracao da midia
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: modifica a duracao da midia
*/
void AtribuiDuracaoMidia(Midia *m,float duracao);

/* Retorna nome da midia
* inputs: Ponteiro para midia
* output: ponteiro para o nome da midia
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
char * RetornaNomeMidia(Midia *m);

/* Retorna nome do cantor
* inputs: Ponteiro para midia
* output: ponteiro para o nome do cantor
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
char * RetornaNomeCantor(Midia *m);

/* Retorna nome do compositor
* inputs: Ponteiro para midia
* output: ponteiro para o nome do compositor
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
char * RetornaNomeCompoditor(Midia *m);

/* Retorna genero da midia
* inputs: Ponteiro para midia
* output: ponteiro para o genero da midia
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
char * RetornaNomeGenero(Midia *m);

/* Retorna nome da gravadora
* inputs: Ponteiro para midia
* output: ponteiro para o nome da gravadora da midia
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
char * RetornaNomeGravdora(Midia *m);

/* Retorna a duracao da midia
* inputs: Ponteiro para midia
* output:  float da duracao da midia
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
float RetornaDuracaoMidia(Midia *m);

/*Libera memória alocada para a maidia
* inputs: ponteiro para midia
* output: nenhum
* pre-condicao: Midia m existe  
* pos-condicao: toda a memória alocada para matriz foi liberada
*/
int RetornaTipoMidia(Midia *m);
/* Retorna o tipo da midia
* inputs: Ponteiro para midia
* output: inteiro do tipo da midia (1 musica,2 video,3 podcast)
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void ApagaMidia(Midia *m);

/* Imprime uma musica
* inputs: Ponteiro para midia
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void ImprimeMusica(Midia *m);

/* Imprime uma musica para arquivo
* inputs: Ponteiro para midia e ponteiro para um arquivo .txt
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void ImprimeMusicaArquivo(FILE *playlist,Midia *m);


/* Imprime um video
* inputs: Ponteiro para midia
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void ImprimeVideo(Midia *m);


/* Imprime um video para arquivo
* inputs: Ponteiro para midia e ponteiro para um arquivo .txt
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void ImprimeVideoArquivo(FILE *playlist,Midia *m);


/* Imprime um podcast
* inputs: Ponteiro para midia
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void ImprimePodcast(Midia *m);

/* Imprime um podcast para arquivo
* inputs: Ponteiro para midia e ponteiro para um arquivo .txt
* output: nenhum
* pre-condicao: midia ter sido devidamente alocada
* pos-condicao: nenhuma
*/
void ImprimePodcastArquivo(FILE *playlist,Midia *m);


/* as 3 funcoes abaixo são responsaveis pela leitura de midias do arquivo
* inputs: ponteiro para um arquivo .txt
* output: ponteiro para midia
* pre-condicao: a leitura do arquivo ter sido bem sucedida
* pos-condicao: ponteiro de midia preenchido
*/
Midia * LePodcastArquivo(FILE *arq);

Midia * LeMusicaArquivo(FILE *arq);

Midia * LeVideoArquivo(FILE *arq);

#endif