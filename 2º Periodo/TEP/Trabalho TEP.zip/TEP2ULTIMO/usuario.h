#ifndef USUARIO_
#define USUARIO_

typedef struct usuario Usuario;

typedef struct playlist Playlist;

/*Inicializa um usuario
* inputs: nenhum
* output: ponteiro para o usuario inicializado
* pre-condicao: nenhuma
* pos-condicao:usuario de retorno existe
*/
Usuario * AlocaUsuario();

/*Atribui nome de usuario
* inputs: ponteiro para usuario,ponteiro para o nome que sera atribuido
* output: nenhum
* pre-condicao: os ponteriros serem validos
* pos-condicao:nenhuma
*/
void AtribuiNomeUsuario(Usuario *u,char *nome,int indice);


/*Atribui Login de usuario(que sera o usado pelo usuario para acessar o sistema)
* inputs: ponteiro para usuario,ponteiro para o login que sera atribuido
* output: nenhum
* pre-condicao: os ponteriros serem validos
* pos-condicao:nenhuma
*/
void AtribuiLoginUsuario(Usuario *u,char *login);

/*Atribui senha de usuario
* inputs: ponteiro para usuario,ponteiro para a senha que sera atribuido
* output: nenhum
* pre-condicao: os ponteriros serem validos
* pos-condicao:nenhuma
*/
void AtribuiSenhaUsuario(Usuario *u,char *senha);

/*Funcão para a imprimir todas as informações do usuario
* inputs: ponteiro para usuario,inteiro que representa a quantidade de playlist do usuario no momento
* (A cada vez q uma playlist eh atribuida ao usuario esse numero eh incrementado, atraves de uma outra função)
* output: nenhum
* pre-condicao: o ponteiro e o inteiro serem validos
* pos-condicao:nenhuma
*/
void ImprimeUsuario(Usuario *u,int i);

/*Funcão para a imprimir apenas o nome do usuario
* inputs: ponteiro para usuario
* output: nenhum
* pre-condicao: o ponteiro ser valido 
* pos-condicao:nenhuma
*/
void ImprimeNomeUsuario(Usuario *u);

/*Atribui um ponteiro para playlist a um usuario
* inputs: ponteiro para usuario,ponteiro playlist e um inteiro
* o inteiro representa o indice da posicao livre das playlists do usuario
* output: nenhum
* pre-condicao: os ponteriros serem validos e o 
 *indice representar a proxima posição livre que pode receber uma playlist
* pos-condicao:nenhuma
*/
void AtribuirPlaylistAoUsuario(Usuario *u,Playlist *p,int indicePlay);

/*Confere o login e senha do usuario
* inputs: ponteiro para usuario,ponteiro para o login e um ponterio para senha
* output: retorna 1,se o login foi efetuado com sucesso e 0 caso contrario
* pre-condicao: os ponteriros serem validos
* pos-condicao:nenhuma
*/
int FazerLogin(Usuario *u,char *login,char *senha);

/*Retorna o login do usuario
* inputs: ponteiro para usuario
* output: char login do usuario
* pre-condicao: o ponteriro ser valido
* pos-condicao:nenhuma
*/
char* RetornaLoginUser(Usuario *u);

/*Retorna a qtd de playlist de um usuario
* inputs: ponteiro para usuario
* output: inteiro da qtd de playlist do usuario
* pre-condicao: o ponteriro ser valido
* pos-condicao:nenhuma
*/
int RetornaQtdPlay(Usuario *u);

/*Incializa a qtd de playlist de um usuario com 0
* inputs: ponteiro para usuario
* output: nenhum
* pre-condicao: o ponteriro ser valido
* pos-condicao: modifica a qtd de playlist de um usuario para 0,inicialmente
*/
void iniciaQtdPlay(Usuario *u);

/*Incrementa a qtd de playlist de um usuario
* inputs: ponteiro para usuario
* output: nenhum
* pre-condicao: o ponteriro ser valido
* pos-condicao: modifica a qtd de playlist 
*/
void incrementalQtdPlay(Usuario *u);

/*Decrementa a qtd de playlist de um usuario
* inputs: ponteiro para usuario
* output: nenhum
* pre-condicao: o ponteriro ser valido
* pos-condicao: modifica a qtd de playlist 
*/
void decrementalQtdPlay(Usuario *u);

/*Retorna posicao livre da playlist do usuario
* inputs: ponteiro para usuario
* output: posicao livre
* pre-condicao: o ponteriro ser valido
* pos-condicao: retorna o inteiro
*/
int RetornaPosicaoLivreUser(Usuario *u);


/*Incrementa a posicao livre da playlist do usuario;
* a cada playlist preenchida,chama essa funçao para fazer o incremento
* inputs: ponteiro para usuario
* output: nenhum
* pre-condicao: o ponteriro ser valido
* pos-condicao: nenhuma
*/
void IncrementaPosicaoLivreUser(Usuario *u);

/*Atribui um ponteiro para playlist de favoritos a um usuario
* inputs: ponteiro para usuario,ponteiro playlist e um inteiro
* output: nenhum
* pre-condicao: os ponteriros serem validos
* pos-condicao:nenhuma
*/
void AtribuiFavoritosUsuario(Usuario *u,Playlist *p,int indicePlay);

/*Funcao que salva os usuarios em um arquivo .txt
* inputs: ponteiro para usuario e a qtd de usuarios no gerenciador
* output: ponteiro para arquivo .txt
* pre-condicao: os ponteriros serem validos
* pos-condicao: ponteiro para arquivo salvo
*/
FILE * SalvarUsuarios(Usuario *u[3],int qtdUser);

/*Funcao que lê um usuarios de um arquivo .txt
* inputs: ponteiro para arquivo e a qtd de usuarios no gerenciador
* output: ponteiro para arquivo .txt
* pre-condicao: os ponteriros serem validos
* pos-condicao: ponteiro para um usuario preenchido
*/
Usuario * LerUsuarioArquivo(FILE *arq,int qtdUser);

/*compara as strings dos nomes dos donos
* inputs: ponteiro para usuario e um ponteiro para char
* output: interiro 0 ou 1, verdadeiro ou falso
* pre-condicao: os ponteriros serem validos
* pos-condicao: verdadeiro ou falso
*/
int ComparaUsuario(Usuario *u,char *dono);

#endif