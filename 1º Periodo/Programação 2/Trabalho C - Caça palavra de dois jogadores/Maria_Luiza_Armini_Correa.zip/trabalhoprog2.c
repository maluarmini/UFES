#include <stdio.h>
#include <stdlib.h>
#include<string.h>
//TRABALHO DE PROG:MARIA LUIZA ARMINI CORREA.

typedef struct {
    int jogadas;
    int coord1;
    int coord2;
} tJogo;

typedef struct {
    char Nomedojogador1[17];
    char Nomedojogador2[17];
    int qtddeespacos1;
    int qtddeespacos2;
    int cont1;
    int cont2;
} tJogador;

typedef struct {
    char tabuleiro[101][101];
    char tabuleiroinicial[101][101];
    int contador;
    int InicialDaPalavraEncontrada;
    int EhPalavraDoPrimeiro;
    int EhPalavraDoSegundo;
    int condicao;
    char MapaOrdenado[101][101];
    int RtnParaMapa;
    int TamanhoDaPalavra;
    int RodadaEncontradaGeral[50];
} tTabuleiro;

typedef struct {
    int jogadas;
    int tamanho;
    char letras[100][100];
    char palavrasjogador[50][17];
    char palavrasjogador1[26][17];
    char palavrasjogador2[26][17];
    int numpalavras;
    int palavrasencontradas1;
    int palavrasencontradas2;
} tConfig;

typedef struct {
    int pontuacao1;
    int pontuacao2;
    int pontuacaofeita1;
    int pontuacaorecebida1;
    int pontuacaofeita2;
    int pontuacaorecebida2;
} tPontuacao;

typedef struct {//Modifiquei na aula de correcao;
    char MatrizDeJogadas[100][2];//Eu havia alocado apenas 26 espacos pra essa matriz!!!
} tJogada;

typedef struct {
    char MatrizDePalavrasEncontradasPeloDono[25][17];
    char MatrizDePalavrasEncontradasPeloOponente[25][17];
    char MatrizDePalavrasNaoEncontradas[51][17];
    int RodadaEncontradaDONO[25];
    int RodadaEncontradaOPONENTE[25];
    int TamMatrizDoDono;
    int TamMatrizDoOponente;
    int TamMatizDasNaoEncontradas;
} tEstatisticas;

typedef struct {
    char mapa[101][101];
} tMapa;
int RetornaCoord1(tJogo jogo) {
    return jogo.coord1;
}

int RetornaCoord2(tJogo jogo) {
    return jogo.coord2;
}

int RetornaRetornoPraMapa(tTabuleiro tabuleiro){
    return tabuleiro.RtnParaMapa;
}

int RetornaTamDaPalavra(tTabuleiro tabuleiro){
    return tabuleiro.TamanhoDaPalavra;
}

tMapa PreencheMapaOrdenado(tMapa mapa,tConfig config1){
    int i=0,j=0,tam;
    for(i=0;i<config1.tamanho;i++){
        for(j=0;j<(2*config1.tamanho);j++){
            mapa.mapa[i][j]='-';
        }
    }
    return mapa;
}
//Funcao Responsavel por preencher e atualiza o Mapa Ordenado!!!
tMapa MapaOrdenado(tMapa mapa,tTabuleiro tabuleiro,tJogo jogo,int rodadamapa){
    int i=0,j=0,rodada,rtn,int1,int2,coord1,coord2,coord2Equi,coord3Equi,tam;
    char caracter,caracter1,caracter2;
    coord1=RetornaCoord1(jogo);
    coord2=RetornaCoord2(jogo);
    coord2Equi=coord2*2;
    coord3Equi=(coord2*2)+1;
    rodada=rodadamapa;
    rtn=RetornaRetornoPraMapa(tabuleiro);
    tam=RetornaTamDaPalavra(tabuleiro);
    caracter=rodada+'0';
    if(rodada<=9){
        if(rtn==1){//Achei palavra a baixo;
            for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
            mapa.mapa[coord1][coord2Equi]='0';
            mapa.mapa[coord1][coord3Equi]=caracter;
         }
           coord1++;
            }
       }else if(rtn==3){//Achei palavra a cima;
           for(i=0;i<tam;i++){
               if(mapa.mapa[coord1][coord2Equi]=='-'){
            mapa.mapa[coord1][coord2Equi]='0';
            mapa.mapa[coord1][coord3Equi]=caracter;
           }
           coord1--;
           }
       }else if(rtn==2){//Achei palavra a esquerda;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]='0';
               mapa.mapa[coord1][coord3Equi]=caracter;
           }
                coord2Equi=coord2Equi+2;
               coord3Equi=coord3Equi+2;
           }
       }else if(rtn==4){//achei palavra a direita;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]='0';
               mapa.mapa[coord1][coord3Equi]=caracter;
           }
            coord2Equi=coord2Equi-2;
            coord3Equi=coord3Equi-2;
           }
       }else if(rtn==5){//achei palavra na diagonal subindo pra direita;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]='0';
               mapa.mapa[coord1][coord3Equi]=caracter;
           }
                coord1--;
               coord2Equi=coord2Equi+2;
               coord3Equi=coord3Equi+2;
           }
       }else if(rtn==6){//achei palavra na diagonal descendo pra direita;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]='0';
               mapa.mapa[coord1][coord3Equi]=caracter;
           }
               coord1++;
               coord2Equi=coord2Equi+2;
               coord3Equi=coord3Equi+2;
           }
       }else if(rtn==7){//achei palavra na diagonal subindo pra esquerda;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]='0';
               mapa.mapa[coord1][coord3Equi]=caracter;
           }
                coord1--;
               coord2Equi=coord2Equi-2;
               coord3Equi=coord3Equi-2;
           }
       }else if(rtn==8){
           for(i=0;i<tam;i++){//achei palavra na diagonal descendo pra esquerda;
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]='0';
               mapa.mapa[coord1][coord3Equi]=caracter;
                }
                coord1++;
               coord2Equi=coord2Equi-2;
               coord3Equi=coord3Equi-2;
           }
       }
    }else{//Tratamento de posiveis rodadas q estrapolem '9';
        int2=rodada%10;
        int1=rodada/10;
        caracter1=int1+'0';
        caracter2=int2+'0';
        if(rtn==1){//Achei palavra a baixo;
            for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
            mapa.mapa[coord1][coord2Equi]=caracter1;
            mapa.mapa[coord1][coord3Equi]=caracter2;
         }
           coord1++;
            }
       }else if(rtn==3){//Achei palavra a cima;
           for(i=0;i<tam;i++){
               if(mapa.mapa[coord1][coord2Equi]=='-'){
            mapa.mapa[coord1][coord2Equi]=caracter1;
            mapa.mapa[coord1][coord3Equi]=caracter2;
           }
           coord1--;
           }
       }else if(rtn==2){//Achei palavra a esquerda;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]=caracter1;
               mapa.mapa[coord1][coord3Equi]=caracter2;
           }
                coord2Equi=coord2Equi+2;
               coord3Equi=coord3Equi+2;
           }
       }else if(rtn==4){//achei palavra a direita;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]=caracter1;
               mapa.mapa[coord1][coord3Equi]=caracter2;
           }
            coord2Equi=coord2Equi-2;
            coord3Equi=coord3Equi-2;
           }
       }else if(rtn==5){//achei palavra na diagonal subindo pra direita;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]=caracter1;
               mapa.mapa[coord1][coord3Equi]=caracter2;
           }
                coord1--;
               coord2Equi=coord2Equi+2;
               coord3Equi=coord3Equi+2;
           }
       }else if(rtn==6){//achei palavra na diagonal descendo pra direita;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]=caracter1;
               mapa.mapa[coord1][coord3Equi]=caracter2;
           }
               coord1++;
               coord2Equi=coord2Equi+2;
               coord3Equi=coord3Equi+2;
           }
       }else if(rtn==7){//achei palavra na diagonal subindo pra esquerda;
           for(i=0;i<tam;i++){
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]=caracter1;
               mapa.mapa[coord1][coord3Equi]=caracter2;
           }
                coord1--;
               coord2Equi=coord2Equi-2;
               coord3Equi=coord3Equi-2;
           }
       }else if(rtn==8){
           for(i=0;i<tam;i++){//achei palavra na diagonal descendo pra esquerda;
                if(mapa.mapa[coord1][coord2Equi]=='-'){
               mapa.mapa[coord1][coord2Equi]=caracter1;
               mapa.mapa[coord1][coord3Equi]=caracter2;
                }
                coord1++;
               coord2Equi=coord2Equi-2;
               coord3Equi=coord3Equi-2;
           }
       }
    }
    tabuleiro.TamanhoDaPalavra=1;
    return mapa;
}

tEstatisticas OrganizaInformacoesDasEstatisticas(tEstatisticas estatisticas1) {
    //funcao que coloca as palavras e jogadas em ordem pra printar de acordo com o pedido no arquivo de estatisticas;
    int i = 0, j = 0, cmp, k = 0;
    char aux[26], aux2[26];
    int auxposicoes, parada;
    parada = estatisticas1.TamMatrizDoDono;
    for (j = 0; j < parada; j++) {//Organiza as palavras com valor de 2 pontos(achadas por seu proprio dono);
        for (i = 0; i < parada; i++) {//essa funcao tbm organiza o vetor do numero da jogada;
            cmp = strcmp(estatisticas1.MatrizDePalavrasEncontradasPeloDono[i], estatisticas1.MatrizDePalavrasEncontradasPeloDono[i + 1]);
            if (cmp > 0) {
                if (estatisticas1.MatrizDePalavrasEncontradasPeloDono[i + 1][0] == '\0') {
                    break;
                }
                strcpy(aux, estatisticas1.MatrizDePalavrasEncontradasPeloDono[i + 1]);
                auxposicoes = estatisticas1.RodadaEncontradaDONO[i + 1];
                strcpy(estatisticas1.MatrizDePalavrasEncontradasPeloDono[i + 1], estatisticas1.MatrizDePalavrasEncontradasPeloDono[i]);
                estatisticas1.RodadaEncontradaDONO[i + 1] = estatisticas1.RodadaEncontradaDONO[i];
                strcpy(estatisticas1.MatrizDePalavrasEncontradasPeloDono[i], aux);
                estatisticas1.RodadaEncontradaDONO[i] = auxposicoes;
            }
        }
    }
    parada = estatisticas1.TamMatrizDoOponente;
    for (j = 0; j < parada; j++) {//Organiza as palavras com o valor de 1 ponto(encontradas pelo oponente)
        for (i = 0; i < parada; i++) {//essa funcao tbm organiza o vetor do numero da jogada;
            cmp = strcmp(estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i], estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i + 1]);
            if (cmp > 0) {
                if (estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i + 1][0] == '\0') {
                    break;
                }
                strcpy(aux, estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i + 1]);
                auxposicoes = estatisticas1.RodadaEncontradaOPONENTE[i + 1];
                strcpy(estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i + 1], estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i]);
                estatisticas1.RodadaEncontradaOPONENTE[i + 1] = estatisticas1.RodadaEncontradaOPONENTE[i];
                strcpy(estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i], aux);
                estatisticas1.RodadaEncontradaOPONENTE[i] = auxposicoes;
            }
        }
    }
    parada = estatisticas1.TamMatizDasNaoEncontradas;//Organiza as palavras com valor 0.
    for (i = 0; i < parada; i++) {
        if (estatisticas1.MatrizDePalavrasNaoEncontradas[i][0] == '\0' && estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1][0] != '\0') {
            strcpy(estatisticas1.MatrizDePalavrasNaoEncontradas[i], estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1]);
            estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1][0] = '\0';
        }
        k = i + 1;
        if (estatisticas1.MatrizDePalavrasNaoEncontradas[i][0] == '\0' && estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1][0] == '\0') {
            while (estatisticas1.MatrizDePalavrasNaoEncontradas[k][0] == '\0' && k < parada) {
                k++;
            }
            strcpy(estatisticas1.MatrizDePalavrasNaoEncontradas[i], estatisticas1.MatrizDePalavrasNaoEncontradas[k]);
            estatisticas1.MatrizDePalavrasNaoEncontradas[k][0] = '\0';
        }
    }
    for (j = 0; j < parada; j++) {
        for (i = 0; i != parada; i++) {
            cmp = strcmp(estatisticas1.MatrizDePalavrasNaoEncontradas[i], estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1]);
            if (cmp > 0) {
                if (estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1][0] == '\0') {
                    break;
                }
                strcpy(aux2, estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1]);
                strcpy(estatisticas1.MatrizDePalavrasNaoEncontradas[i + 1], estatisticas1.MatrizDePalavrasNaoEncontradas[i]);
                strcpy(estatisticas1.MatrizDePalavrasNaoEncontradas[i], aux2);
            }
        }
    }
    return estatisticas1;
}

tTabuleiro GuardaTabuleiroInicial(tTabuleiro tabuleiroinicial, tTabuleiro tabuleiro, tConfig config1) {
    //essa funcao é utilizada para auxiliar na conferencia das coordenadas e quando necessario retornar esse tabuleiro sem possiveis
    //alteracoes feitas em alguma outra funcao!
    int i = 0, j = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];
        }
    }
    return tabuleiroinicial;
}

tConfig SeparaPalavrasJogador1e2(tConfig config1) {
    //as palavras do jogador 1 e 2, quem entram no config não vem separadas,e ter elas separadas auxilia em algumas etapas do programa.
    int i = 0, j = 0;
    for (i = 0; i < config1.numpalavras; i++) {
        strcpy(config1.palavrasjogador1[i], config1.palavrasjogador[i]);
    }
    for (j = 0; j < config1.numpalavras; j++) {
        strcpy(config1.palavrasjogador2[j], config1.palavrasjogador[i]);
        i++;
    }
    config1.palavrasencontradas1 = config1.numpalavras;
    config1.palavrasencontradas2 = config1.numpalavras;
    return config1;
}

tEstatisticas ArmazenaRodadaEmQueAPalavrafoiEncontradaDONO(tEstatisticas estatisticas1, int rodada) {
    //Vetor de jogadas.
    //inf das estastisticas;
    int i = 0;
    rodada = rodada + 1;
    while (estatisticas1.RodadaEncontradaDONO[i] != '\0') {
        i++;
    }
    estatisticas1.RodadaEncontradaDONO[i] = rodada;
    return estatisticas1;
}

tEstatisticas ArmazenaRodadaEmQueAPalavrafoiEncontradaOPONENTE(tEstatisticas estatisticas1, int rodada) {
    //Vetor de jogadas;
    //inf das estatisticas;
    int i = 0;
    rodada = rodada + 1;
    while (estatisticas1.RodadaEncontradaOPONENTE[i] != '\0') {
        i++;
    }
    estatisticas1.RodadaEncontradaOPONENTE[i] = rodada;
    return estatisticas1;
}

int TamanhoNome1(tJogador jogador) {//conta o tamanho do nome dos jogadores
    int cont1 = 0;
    while (jogador.Nomedojogador1[cont1] != '\0') {
        cont1++;
    }
    return cont1;
}

int TamanhoNome2(tJogador jogador) {
    int cont2 = 0;
    while (jogador.Nomedojogador2[cont2] != '\0') {
        cont2++;
    }
    return cont2;
}

void ListasDePalavrasRestantesCabecalho(tJogador jogador, tTabuleiro tabuleiro, tPontuacao pontuacao) {
    int i = 0;
    printf("|            Palavras Restantes           |\n");
    printf("|%s", jogador.Nomedojogador1);
    for (i = 1; i < jogador.qtddeespacos1; i++) {
        printf(" ");
    }
    printf("(%.2d)", pontuacao.pontuacao1);
    printf("|%s", jogador.Nomedojogador2);
    for (i = 1; i < jogador.qtddeespacos2; i++) {
        printf(" ");
    }
    printf("(%.2d)", pontuacao.pontuacao2);
    printf("|\n");
    printf("|--------------------|--------------------|\n");
}

void ListasDePalavrasRestantesCorpoPt1(tConfig config1) {
    int i = 0;
    for (i = 0; i < config1.numpalavras; i++) {
        printf("|%-20s|%-20s|\n", config1.palavrasjogador[i], config1.palavrasjogador[i + config1.numpalavras]);
    }
}
//Funcoes tPontuacao//Armazenam as informacoes sobre os pontos(separados) de cada jogador!
//essas informacoes tbm sao utilizadas nas estatisticas;
tPontuacao PontuacaoFeitaJogador1(tPontuacao pontuacao) {
    pontuacao.pontuacaofeita1 = pontuacao.pontuacaofeita1 + 2;
    pontuacao.pontuacao1 = pontuacao.pontuacaorecebida1 + pontuacao.pontuacaofeita1;
    return pontuacao;
}

tPontuacao PontuacaoFeitaJogador2(tPontuacao pontuacao) {
    pontuacao.pontuacaofeita2 = pontuacao.pontuacaofeita2 + 2;
    pontuacao.pontuacao2 = pontuacao.pontuacaorecebida2 + pontuacao.pontuacaofeita2;
    return pontuacao;
}

tPontuacao PontuacaoRecebidaJogador1(tPontuacao pontuacao) {
    pontuacao.pontuacaorecebida1 = pontuacao.pontuacaorecebida1 + 1;
    pontuacao.pontuacao1 = pontuacao.pontuacaorecebida1 + pontuacao.pontuacaofeita1;
    return pontuacao;
}

tPontuacao PontuacaoRecebidaJogador2(tPontuacao pontuacao) {
    pontuacao.pontuacaorecebida2 = pontuacao.pontuacaorecebida2 + 1;
    pontuacao.pontuacao2 = pontuacao.pontuacaorecebida2 + pontuacao.pontuacaofeita2;
    return pontuacao;
}

tTabuleiro Tabuleiro(tConfig config1, tTabuleiro tabuleiro, tJogo jogo) {
    int i = 0, j = 0, k = 0;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiro.tabuleiro[i][j] = '-';
        }
        tabuleiro.tabuleiro[i][j++] = '\0';
    }
    printf("\n");
    for (i = 0; i < config1.tamanho; i++) {
        if (i == 0) {
            printf("   ");
        }
        printf(" %.2d", i);
    }
    printf("\n");
    for (i = 0; i < config1.tamanho; i++) {
        if (i >= 1) {
            printf("\n");
        }
        for (i = 0; i < config1.tamanho; i++) {
            if (i >= 1) {
                printf("\n");
            }
            printf("%.2d| ", i);
            for (j = 0; j < config1.tamanho; j++) {
                if (j == config1.tamanho - 1) {
                    printf("%c ", tabuleiro.tabuleiro[i][j]);
                    continue;
                }
                printf("%c  ", tabuleiro.tabuleiro[i][j]);
            }
            printf("|");
        }
    }
    printf("\n\n");
    return tabuleiro;
}

int RetornaTamanhoDoTabuleiro(tConfig config1) {
    return config1.tamanho;
}

int RetornaNumeroDeJogadas(tConfig config1) {
    return config1.jogadas;
}

int NumeroDePalavras(tConfig config1) {
    return config1.numpalavras;
}

tJogada IniciaMatrizDeJogadas(tJogada jogada, tConfig config1) {//na hora de inicializar eu tbm modifiquei,a condicao de parada pra 100;
    //Matriz de jogadas usada para auxiliar no tratamento de jogadas
    //nao ordinarias;
    int i = 0, j = 0, tam;
    tam = RetornaTamanhoDoTabuleiro(config1);
    for (i = 0; i < 100; i++) {
        for (j = 0; j < 2; j++) {
            jogada.MatrizDeJogadas[i][j] = (tam + 10);
        }
    }
    return jogada;
}

tJogada AtualizaMatrizDeJogadas(tJogada jogada, int rodada, tJogo jogo) {
    //tratamento de jogadas nao ordinarias;(manter a matriz atualizada,para saber se uma jogada ja ocorreu).
    int coord1, coord2;
    coord1 = RetornaCoord1(jogo);
    coord2 = RetornaCoord2(jogo);
    jogada.MatrizDeJogadas[rodada][0] = coord1;
    jogada.MatrizDeJogadas[rodada][1] = coord2;
    return jogada;
}

int VerificaSeACoordTaNaMatrizDeJogadas(tJogada jogada, tJogo jogo) {//Na aula de correcao eu mudei o tamanho do loop, pois aloquei mais espaco pra matriz;
    //tratamento de jogadas nao ordinarias;(manter a matriz atualizada,para saber se uma jogada ja ocorreu).
    int i = 0, j = 0, coord1, coord2;
    coord1 = RetornaCoord1(jogo);
    coord2 = RetornaCoord2(jogo);
    for (i = 0; i < 100; i++) {
        for (j = 0; j < 1; j++) {
            if (jogada.MatrizDeJogadas[i][j] == coord1 && jogada.MatrizDeJogadas[i][j + 1] == coord2) {
                return 1;
            } else {
                continue;
            }
        }
    }
    return 0;
}

int ContaTamanhoDaPalavra1(tConfig config1, int i) {
    int cont = 0;
    while (config1.palavrasjogador[i][cont] != '\0') {//descobri o tamanho da palavra;
        cont++;
    }
    return cont;
}

//A seguir, todas as funcoes responsaveis por fazer a conferencia e o preenchimento do tabuleiro;

tTabuleiro ConfereSeTaPraBaixo1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    tabuleiroinicial = GuardaTabuleiroInicial(tabuleiroinicial, tabuleiro, config1);
    coordinicial = jogo.coord1;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        tabuleiro.InicialDaPalavraEncontrada = i;
        cont = 0;
        while (config1.palavrasjogador[l][cont] != '\0') {
            cont++;
        }
        tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord1 = coordinicial + k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    tabuleiro.contador++;
                    return tabuleiro;
                    continue;
                }
                continue;
            }
            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                tabuleiro.TamanhoDaPalavra = tam;
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord1++;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord1 = coordinicial;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord1 = coordinicial;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        tabuleiro.contador++;
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereSeTaProLadoEsquerdo1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];
        }
    }
    coordinicial = jogo.coord2;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        cont = 0;
        tabuleiro.InicialDaPalavraEncontrada = i;
        while (config1.palavrasjogador[l][cont] != '\0') {//descobri o tamanho da palavra;
            cont++;
        }
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord2 = coordinicial + k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    if (tam == cont) {
                        tabuleiro.contador++;
                        return tabuleiro;
                    }
                }
                continue;
            }
            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                tabuleiro.TamanhoDaPalavra = tam;
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord2++;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord2 = coordinicial;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord2 = coordinicial;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereSeTaPraCima1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];
        }
    }
    coordinicial = jogo.coord1;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        cont = 0;
        tabuleiro.InicialDaPalavraEncontrada = i;
        while (config1.palavrasjogador[l][cont] != '\0') {//descobri o tamanho da palavra;
            cont++;
        }
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord1 = coordinicial - k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    tabuleiro.contador++;
                    return tabuleiro;
                }
                continue;
            }
            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord1--;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord1 = coordinicial;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord1 = coordinicial;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereSeTaProLadoDireito1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];

        }
    }
    coordinicial = jogo.coord2;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        cont = 0;
        tabuleiro.InicialDaPalavraEncontrada = i;
        while (config1.palavrasjogador[l][cont] != '\0') {//descobri o tamanho da palavra;
            cont++;
        }
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord2 = coordinicial - k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    tabuleiro.contador++;
                    return tabuleiro;
                }
                continue;
            }
            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        tabuleiro.TamanhoDaPalavra = tam;
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord2--;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord2 = coordinicial;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord2 = coordinicial;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereSeTaNaDiagonalSubindo1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial1, coordinicial2, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];
        }
    }
    coordinicial1 = jogo.coord1;
    coordinicial2 = jogo.coord2;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        cont = 0;
        tabuleiro.InicialDaPalavraEncontrada = i;
        while (config1.palavrasjogador[l][cont] != '\0') {//descobri o tamanho da palavra;
            cont++;
        }
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord1 = coordinicial1 - k;
            jogo.coord2 = coordinicial2 + k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    tabuleiro.contador++;
                    return tabuleiro;
                }
                continue;
            }
            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord1--;
                            jogo.coord2++;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord1 = coordinicial1;
                                    jogo.coord2 = coordinicial2;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord1 = coordinicial1;
                jogo.coord2 = coordinicial2;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereSeTaNaDiagonalDescendo1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial1, coordinicial2, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];
        }
    }
    coordinicial1 = jogo.coord1;
    coordinicial2 = jogo.coord2;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        cont = 0;
        tabuleiro.InicialDaPalavraEncontrada = i;
        while (config1.palavrasjogador[l][cont] != '\0') {//descobri o tamanho da palavra;
            cont++;
        }
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord1 = coordinicial1 + k;
            jogo.coord2 = coordinicial2 + k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    tabuleiro.contador++;
                    return tabuleiro;
                }
                continue;
            }
            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord1++;
                            jogo.coord2++;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord1 = coordinicial1;
                                    jogo.coord2 = coordinicial2;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord1 = coordinicial1;
                jogo.coord2 = coordinicial2;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereSeTaNaDiagonalContrariaDescendo1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial1, coordinicial2, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];
        }
    }
    coordinicial1 = jogo.coord1;
    coordinicial2 = jogo.coord2;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        cont = 0;
        tabuleiro.InicialDaPalavraEncontrada = i;
        while (config1.palavrasjogador[l][cont] != '\0') {//descobri o tamanho da palavra;
            cont++;
        }
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord1 = coordinicial1 + k;
            jogo.coord2 = coordinicial2 - k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    tabuleiro.contador++;
                    return tabuleiro;
                }
                continue;
            }

            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord1++;
                            jogo.coord2--;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord1 = coordinicial1;
                                    jogo.coord2 = coordinicial2;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord1 = coordinicial1;
                jogo.coord2 = coordinicial2;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereSeTaNaDiagonalContrariaSubindo1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, int l, int iniciador, int parador) {
    int i = 0, j = 0, k = 0, coordinicial1, coordinicial2, cont = 0, tam = 0, soma = 0;
    tTabuleiro tabuleiroinicial;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        for (j = 0; j < config1.tamanho; j++) {
            tabuleiroinicial.tabuleiro[i][j] = tabuleiro.tabuleiro[i][j];
        }
    }
    coordinicial1 = jogo.coord1;
    coordinicial2 = jogo.coord2;
    iniciador = iniciador;
    parador = parador;
    for (i = iniciador; i < parador; i++) {
        cont = 0;
        tabuleiro.InicialDaPalavraEncontrada = i;
        soma = 0;
        while (config1.palavrasjogador[l][cont] != '\0') {//descobri o tamanho da palavra;
            cont++;
        }
        for (k = 0; k < cont; k++) {
            if (k == 0) {
                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][0]) {
                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k] - 32;
                    continue;
                } else {
                    break;
                }
            }
            jogo.coord1 = coordinicial1 - k;
            jogo.coord2 = coordinicial2 - k;
            tam = ContaTamanhoDaPalavra1(config1,i);
            tabuleiro.TamanhoDaPalavra=tam;
            if (tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k] - 32) {
                if (k == cont - 1) {
                    tabuleiro.contador++;
                    return tabuleiro;
                }
                continue;
            }
            if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                tam = ContaTamanhoDaPalavra1(config1, i);
                if (k == cont - 1 || tam == cont) {
                    if (k == cont - 1) {
                        tam = ContaTamanhoDaPalavra1(config1, i);
                        if (tam == cont) {
                            tabuleiro.contador++;
                            return tabuleiro;
                        } else {
                            jogo.coord1--;
                            jogo.coord2--;
                            k++;
                            while (config1.palavrasjogador[i][k] != '\0') {
                                if (config1.letras[jogo.coord1][jogo.coord2] == config1.palavrasjogador[i][k]) {
                                    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.palavrasjogador[i][k];
                                    soma++;
                                } else {
                                    jogo.coord1 = coordinicial1;
                                    jogo.coord2 = coordinicial2;
                                    break;
                                }
                                k++;
                            }
                            if (soma == tam - cont) {
                                tabuleiro.contador++;
                                return tabuleiro;
                            }
                        }
                    }
                }
            } else {
                jogo.coord1 = coordinicial1;
                jogo.coord2 = coordinicial2;
                break;
            }
        }
    }
    if (tabuleiro.contador >= 1) {
        return tabuleiro;
    } else {
        tabuleiroinicial.contador = 0;
        return tabuleiroinicial;
    }
}

tTabuleiro ConfereCoordenadasjogador1(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, tJogador jogador, tEstatisticas estatisticas1) {
    int p = 0, i = 0, iniciador, parador;
    tabuleiro.contador = 0;
    tabuleiro.condicao = 0;
    iniciador = 0;
    parador = config1.numpalavras;
    for (i = 0; i < config1.numpalavras; i++) {
        tabuleiro.InicialDaPalavraEncontrada = i;
        if ((config1.letras[jogo.coord1][jogo.coord2]) == (config1.palavrasjogador[i][0]) || (config1.palavrasjogador[i][0]) == (config1.letras[jogo.coord1][jogo.coord2]) - 32) {
            tabuleiro = ConfereSeTaPraBaixo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 1; //Informa para a funcao tMapa q a palavra ta localizada a baixo;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaProLadoEsquerdo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 2;//Informa para a funcao tMapa q a palavra ta localizada a esquerda;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaPraCima1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 3;//Informa para a funcao tMapa q a palavra ta localizada a cima;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaProLadoDireito1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 4;//Informa para a funcao tMapa q a palavra ta localizada a direita;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalSubindo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 5;//Informa para a funcao tMapa q a palavra ta localizada na d.subindo;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalDescendo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 6;//Informa para a funcao tMapa q a palavra ta localizada na d.descendo;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalContrariaSubindo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 7;//Informa para a funcao tMapa q a palavra ta localizada na d. contraria subindo;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalContrariaDescendo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 8;//Informa para a funcao tMapa q a palavra ta localizada na diagonal contraria descendo;
                return tabuleiro;
            }
            continue;
            tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.letras[jogo.coord1][jogo.coord2] - 32;
            return tabuleiro;

        }

    }
    tabuleiro.condicao++;
    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.letras[jogo.coord1][jogo.coord2] - 32;
    return tabuleiro;
}

tTabuleiro ConfereCoordenadasjogador2(tJogo jogo, tConfig config1, tTabuleiro tabuleiro, tJogador jogador) {
    int p = 0, i = 0, iniciador, parador;
    tabuleiro.contador = 0;
    tabuleiro.condicao = 0;
    iniciador = config1.numpalavras;
    parador = 2 * config1.numpalavras;
    for (i = config1.numpalavras; i < 2 * config1.numpalavras; i++) {
        tabuleiro.InicialDaPalavraEncontrada = i;
        if ((config1.letras[jogo.coord1][jogo.coord2]) == (config1.palavrasjogador[i][0]) || (config1.palavrasjogador[i][0]) == (config1.letras[jogo.coord1][jogo.coord2]) - 32) {
            tabuleiro = ConfereSeTaPraBaixo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa= 1;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaProLadoEsquerdo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 2;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaPraCima1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 3;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaProLadoDireito1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 4;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalSubindo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 5;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalDescendo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 6;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalContrariaSubindo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 7;
                return tabuleiro;
            }
            tabuleiro = ConfereSeTaNaDiagonalContrariaDescendo1(jogo, config1, tabuleiro, i, iniciador, parador);
            if (tabuleiro.contador >= 1) {
                i = tabuleiro.InicialDaPalavraEncontrada;
                tabuleiro.RtnParaMapa = 8;
                return tabuleiro;
            }
            continue;
            tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.letras[jogo.coord1][jogo.coord2] - 32;
            return tabuleiro;

        }

    }
    tabuleiro.condicao++;
    tabuleiro.tabuleiro[jogo.coord1][jogo.coord2] = config1.letras[jogo.coord1][jogo.coord2] - 32;
    return tabuleiro;
}

tJogador CriaJogador() {//CRIA JOGADOR 1 E 2;
    tJogador jogador;
    printf("Nome do Jogador 1:\n");
    scanf("%s", jogador.Nomedojogador1);
    jogador.cont1 = TamanhoNome1(jogador);
    jogador.qtddeespacos1 = 17 - jogador.cont1;
    printf("Nome do Jogador 2:\n");
    scanf("%s", jogador.Nomedojogador2);
    jogador.cont2 = TamanhoNome2(jogador);
    jogador.qtddeespacos2 = 17 - jogador.cont2;
    return jogador;
}

tPontuacao InicializaPontuacoes(tPontuacao pontuacao) {//retorna pontuacoes zeradas,descartando lixos;
    pontuacao.pontuacao1 = 0;
    pontuacao.pontuacao2 = 0;
    pontuacao.pontuacaofeita1 = 0;
    pontuacao.pontuacaorecebida1 = 0;
    pontuacao.pontuacaofeita2 = 0;
    pontuacao.pontuacaorecebida2 = 0;
    return pontuacao;
}

void AtualizaEImprimeTabuleiro(tConfig config1, tTabuleiro tabuleiro) {
    int i = 0, j = 0;
    tabuleiro.contador = 0;
    for (i = 0; i < config1.tamanho; i++) {
        if (i == 0) {
            printf("   ");
        }
        printf(" %.2d", i);
    }
    printf("\n");
    for (i = 0; i < config1.tamanho; i++) {
        printf("%.2d|", i);
        for (j = 0; j < config1.tamanho; j++) {
            printf(" %c ", tabuleiro.tabuleiro[i][j]);
        }
        printf("|");
        printf("\n");
    }
    printf("\n");
}

tConfig ExcluiPalavraEncontrada1(tTabuleiro tabuleiro, int i, tConfig config1) {//jogador1
    int j = 0, k = 0;
    config1.palavrasjogador[i][0] = '\0';
    config1.palavrasencontradas1 = config1.palavrasencontradas1 - 1;
    return config1;
}

tConfig ExcluiPalavraEncontrada2(tTabuleiro tabuleiro, int i, tConfig config1) {//jogador2
    int j = 0, k = 0;
    config1.palavrasjogador[i][0] = '\0';
    config1.palavrasencontradas2 = config1.palavrasencontradas2 - 1;
    return config1;
}

tConfig AtualizaPalavrasDeCadaJogador(tConfig config1) {
    int i = 0, j = 0;
    for (i = 0; i < config1.numpalavras; i++) {
        strcpy(config1.palavrasjogador1[i], config1.palavrasjogador[i]);
    }
    for (i = config1.numpalavras; i < 2 * config1.numpalavras; i++) {
        strcpy(config1.palavrasjogador2[j], config1.palavrasjogador[i]);
        j++;
    }
    return config1;
}
//funcao para auxiliar no printf das palavras restantes,trocando as palavras com barra zero e "jogando" elas pra baixo;
tConfig TrocaPalavras(tConfig config1, tTabuleiro tabuleiro, int CodigoDoJogador) {
    int i = 0, k = 0, cont = 1;
    if (1) {
        while (i < config1.numpalavras - 1) {
            if (config1.palavrasjogador1[i][0] == '\0' && config1.palavrasjogador1[i + 1][0] != '\0') {
                strcpy(config1.palavrasjogador1[i], config1.palavrasjogador1[i + 1]);
                config1.palavrasjogador1[i + 1][0] = '\0';
            }
            k = i + 1;
            if (config1.palavrasjogador1[i][0] == '\0' && config1.palavrasjogador1[k][0] == '\0') {
                while (config1.palavrasjogador1[k][0] == '\0' && k < config1.numpalavras - 1) {
                    k++;
                }
                strcpy(config1.palavrasjogador1[i], config1.palavrasjogador1[k]);
                config1.palavrasjogador1[k][0] = '\0';
            }
            i++;
        }
    }
    i = 0;
    k = 0;
    if (1) {
        while (i < config1.numpalavras - 1) {
            if (config1.palavrasjogador2[i][0] == '\0' && config1.palavrasjogador2[i + 1][0] != '\0') {
                strcpy(config1.palavrasjogador2[i], config1.palavrasjogador2[i + 1]);
                config1.palavrasjogador2[i + 1][0] = '\0';
            }
            k = i + 1;
            if (config1.palavrasjogador2[i][0] == '\0' && config1.palavrasjogador2[k][0] == '\0') {
                while (config1.palavrasjogador2[k][0] == '\0' && k < config1.numpalavras - 1) {
                    k++;
                }
                strcpy(config1.palavrasjogador2[i], config1.palavrasjogador2[k]);
                config1.palavrasjogador2[k][0] = '\0';
            }
            i++;
        }
    }
    return config1;
}

void ImprimePalavrasRestanteParaTratamentoDeJogadas(tConfig config1, tTabuleiro tabuleiro) {
    int i = 0, j = 1, parada;
    if (config1.palavrasencontradas1 >= config1.palavrasencontradas2) {
        parada = config1.palavrasencontradas1;
    } else {
        parada = config1.palavrasencontradas2;
    }
    for (i = 0; i < parada; i++) {
        printf("|%-20s|%-20s|\n", config1.palavrasjogador1[i], config1.palavrasjogador2[i]);
    }
    printf("\n");
}

tJogo PedidoDeJogada1(tJogador jogador, tJogo jogo, tConfig config1, tTabuleiro tabuleiro, tPontuacao pontuacao) {//PEDE JOGADA E TRATA JOGADAS FORA DO TABULEIRO;
    int tam;
    tam = RetornaTamanhoDoTabuleiro(config1);
    printf("%s por favor entre com as coordenadas para a sua jogada:\n", jogador.Nomedojogador1);
    scanf("%d %d", &jogo.coord1, &jogo.coord2);
    while (1) {
        if ((jogo.coord1 >= 0 && jogo.coord1 < tam)&&(jogo.coord2 >= 0 && jogo.coord2 < tam)) {
            break;
        } else {
            ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
            ImprimePalavrasRestanteParaTratamentoDeJogadas(config1, tabuleiro);
            AtualizaEImprimeTabuleiro(config1, tabuleiro);
            printf("Coordenadas fora do tabuleiro.%s por favor entre com novas coordenadas para a sua jogada:\n", jogador.Nomedojogador1);
            scanf("%d %d", &jogo.coord1, &jogo.coord2);
            continue;
        }
    }
    return jogo;
}

tJogo PedidoDeJogada2(tJogador jogador, tJogo jogo, tConfig config1, tTabuleiro tabuleiro, tPontuacao pontuacao) {//PEDE JOGADA E TRATA JOGADA FORA DO TABULEIRO;
    int tam;
    tam = RetornaTamanhoDoTabuleiro(config1);
    printf("%s por favor entre com as coordenadas para a sua jogada:\n", jogador.Nomedojogador2);
    scanf("%d %d", &jogo.coord1, &jogo.coord2);
    while (1) {
        if ((jogo.coord1 >= 0 && jogo.coord1 < tam)&&(jogo.coord2 >= 0 && jogo.coord2 < tam)) {
            break;
        } else {
            ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
            ImprimePalavrasRestanteParaTratamentoDeJogadas(config1, tabuleiro);
            AtualizaEImprimeTabuleiro(config1, tabuleiro);
            printf("Coordenadas fora do tabuleiro.%s por favor entre com novas coordenadas para a sua jogada:\n", jogador.Nomedojogador2);
            scanf("%d %d", &jogo.coord1, &jogo.coord2);
            continue;
        }
    }
    return jogo;
}

tJogo TratamentoDeJogadaNaoOrdinaria1(tJogada jogada, tJogo jogo, tJogador jogador, tConfig config1, tTabuleiro tabuleiro, tPontuacao pontuacao) {
    int tam;//Essa funcao utiliza das informacoes da "Matriz De Jogadas", verificando se a jogada ja ocorreu e tratando para evitar repeticoes;
    tam = RetornaTamanhoDoTabuleiro(config1);
    while (VerificaSeACoordTaNaMatrizDeJogadas(jogada, jogo) == 1) {
        ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
        ImprimePalavrasRestanteParaTratamentoDeJogadas(config1, tabuleiro);
        AtualizaEImprimeTabuleiro(config1, tabuleiro);
        printf("Coordenadas ja jogadas.%s por favor entre com novas coordenadas para a sua jogada:\n", jogador.Nomedojogador1);
        scanf("%d %d", &jogo.coord1, &jogo.coord2);
        while ((jogo.coord1 < 0 || jogo.coord1 >= tam) || (jogo.coord2 < 0 || jogo.coord2 >= tam)) {
            printf("Coordenadas fora do tabuleiro.%s por favor entre com novas coordenadas para a sua jogada:\n", jogador.Nomedojogador1);
            ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
            ImprimePalavrasRestanteParaTratamentoDeJogadas(config1, tabuleiro);
            AtualizaEImprimeTabuleiro(config1, tabuleiro);
            scanf("%d %d", &jogo.coord1, &jogo.coord2);
        }
    }
    return jogo;
}

tJogo TratamentoDeJogadaNaoOrdinaria2(tJogada jogada, tJogo jogo, tJogador jogador, tConfig config1, tTabuleiro tabuleiro, tPontuacao pontuacao) {
    int tam;//Essa funcao utiliza das informacoes da "Matriz De Jogadas", verificando se a jogada ja ocorreu e tratando para evitar repeticoes;
    tam = RetornaTamanhoDoTabuleiro(config1);
    while (VerificaSeACoordTaNaMatrizDeJogadas(jogada, jogo) == 1) {
        ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
        ImprimePalavrasRestanteParaTratamentoDeJogadas(config1, tabuleiro);
        AtualizaEImprimeTabuleiro(config1, tabuleiro);
        printf("Coordenadas ja jogadas.%s por favor entre com novas coordenadas para a sua jogada:\n", jogador.Nomedojogador2);
        scanf("%d %d", &jogo.coord1, &jogo.coord2);
        while ((jogo.coord1 < 0 || jogo.coord1 >= tam) || (jogo.coord2 < 0 || jogo.coord2 >= tam)) {
            printf("Coordenadas fora do tabuleiro.%s por favor entre com novas coordenadas para a sua jogada:\n", jogador.Nomedojogador2);
            ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
            ImprimePalavrasRestanteParaTratamentoDeJogadas(config1, tabuleiro);
            AtualizaEImprimeTabuleiro(config1, tabuleiro);
            scanf("%d %d", &jogo.coord1, &jogo.coord2);
        }
    }
    return jogo;
}

tConfig AtualizaEImprimePalavrasRestante(tConfig config1, tTabuleiro tabuleiro) {
    int i = 0, j = 1, parada;
    if (config1.palavrasencontradas1 >= config1.palavrasencontradas2) {
        parada = config1.palavrasencontradas1;
    } else {
        parada = config1.palavrasencontradas2;
    }
    for (i = 0; i < parada; i++) {
        printf("|%-20s|%-20s|\n", config1.palavrasjogador1[i], config1.palavrasjogador2[i]);
    }
    printf("\n");
    return config1;
}

int VerificaSeAlguemVenceu(int venceu1, int venceu2, tConfig config1, tJogador jogador) {
    int rtn = 0;
    if (venceu1 == config1.numpalavras) {
        rtn++;
        return rtn;
    }
    if (venceu2 == config1.numpalavras) {
        rtn++;
        return rtn;
    }
    return rtn;
}
//Funcoes auxiliares para a estatistica!
tEstatisticas AtualizaMatrizDePalavrasEncontradasPeloDono(tConfig config1, tEstatisticas estatisticas1, int i, int rodada) {//PALAVARS Q RECEBERAM 2 PTS;
    rodada = 0;//cada palavra encontrada recebe um '\0' e essa funcao percorre até encontra-lo(rodada), e atribui nessa posicao a palavra encontrada;
    		  //e com isso preenche a matriz de palavras encontrada pelo dono (2pontos);
    while (estatisticas1.MatrizDePalavrasEncontradasPeloDono[rodada][0] != '\0') {
        rodada++;
    }
    strcpy(estatisticas1.MatrizDePalavrasEncontradasPeloDono[rodada], config1.palavrasjogador[i]);
    estatisticas1.MatrizDePalavrasNaoEncontradas[i][0] = '\0';
    estatisticas1.TamMatrizDoDono = rodada;
    return estatisticas1;
}

tEstatisticas AtualizaMatrizDePalavrasEncontradasPeloOponente(tConfig config1, tEstatisticas estatisticas1, int i, int rodada) {//PALAVRAS Q RECEBERAM 1 PT;
    rodada = 0;//Analogamente, essa funcao faz o mesmo processo,porem,para as palavras encontradas pelo oponente;
    while (estatisticas1.MatrizDePalavrasEncontradasPeloOponente[rodada][0] != '\0') {
        rodada++;
    }
    strcpy(estatisticas1.MatrizDePalavrasEncontradasPeloOponente[rodada], config1.palavrasjogador[i]);
    estatisticas1.MatrizDePalavrasNaoEncontradas[i][0] = '\0';
    estatisticas1.TamMatrizDoOponente = rodada;
    return estatisticas1;
}

tEstatisticas AtualizaMatrizDePalavrasNaoEncontradas(tConfig config1, tEstatisticas estatisticas1) {//PALAVRAS Q RECEBERAM 0 PT;
    int i = 0, j = 0, aux, parada, cmp = 0, auxposicoes;
    for (i = 0; i < 2 * config1.numpalavras; i++) {
        strcpy(estatisticas1.MatrizDePalavrasNaoEncontradas[i], config1.palavrasjogador[i]);
    }
    estatisticas1.TamMatizDasNaoEncontradas = i;
    parada = estatisticas1.TamMatizDasNaoEncontradas;
    return estatisticas1;
}

int Vencedor(tPontuacao pontuacao) {//Determina o vencedor da partida;
    if (pontuacao.pontuacao1 == pontuacao.pontuacao2) {
        return 0;
    } else if (pontuacao.pontuacao1 > pontuacao.pontuacao2) {
        return 1;
    } else {
        return 2;
    }
}

tConfig LeConfig(int argc, char *argv[]) {
    char config_dir[1000];
    int i = 0, j = 0;
    tConfig config1;
    tTabuleiro tabuleiro;
    if (argc <= 1) {
        printf("ERRO: O diretório de arquivos de configuração não foi informado\n");
        exit(0);
    }
    sprintf(config_dir, "%s/config.txt", argv[1]);
    FILE *config = fopen(config_dir, "r");
    if (config == NULL) {
        printf("Nao foi possivel ler o arquivo: %s\n", argv[1]);
        exit(0);
    }
    //GUARDANDO AS CONFIGURAÇÕES DO CONFIG.TXT;
    fscanf(config, "%d %d", &config1.jogadas, &config1.tamanho);
    tabuleiro.tabuleiro[config1.tamanho][config1.tamanho];
    for (i = 0; i < config1.tamanho; i++) {
        if (i == 0) {
            fscanf(config, "\n");
        }
        for (j = 0; j < config1.tamanho; j++) {
            fscanf(config, "%c", &config1.letras[i][j]);
        }
        fscanf(config, "\n");
    }
    fscanf(config, "%d", &config1.numpalavras);
    for (i = 0; i < 2 * config1.numpalavras; i++) {
        fscanf(config, "%s", config1.palavrasjogador[i]);
    }
    fclose(config);
    return config1;
}

void CriaArquivoExtraDeMapaOrdenado(tMapa mapa, tJogador jogador, tEstatisticas estatistica1, tConfig config1,char *argv[]) {
    int i=0,j=0;
    char mapaordenadosaida[1000];
    sprintf(mapaordenadosaida,"%s/saida/MapaOrdenado.txt",argv[1]);
    FILE *mapaordenado = fopen(mapaordenadosaida, "w");
    for (i = 0; i < config1.tamanho; i++) {
        if(i==0){
            fprintf(mapaordenado," ");
        }
        for (j = 0; j < 2 * config1.tamanho; j++) {
            fprintf(mapaordenado,"%c", mapa.mapa[i][j]);
            if(j!=0&&j%2!=0&&j!=(2*config1.tamanho)-1){
                fprintf(mapaordenado," ");
            }
        }
        if(i==config1.tamanho-1){
            continue;
        }
        fprintf(mapaordenado,"\n ");
    }
    fclose(mapaordenado);
}

void CriaArquivoDeEstatisticas(tJogador jogador, tPontuacao pontuacao, tEstatisticas estatisticas1, tConfig config1, char *argv[]) {
    int i = 0, print = 0;
    char estatisticaSaida[1000];
    estatisticas1 = OrganizaInformacoesDasEstatisticas(estatisticas1);
    sprintf(estatisticaSaida, "%s/saida/Estatisticas.txt", argv[1]);
    FILE *estatisticas = fopen(estatisticaSaida, "w");
    fprintf(estatisticas, "--------------\n--- PONTOS ---\n--------------\n");
    fprintf(estatisticas, "\n%s\nFeitos: %d\nRecebidos: %d\nTotal: %d\n", jogador.Nomedojogador1, pontuacao.pontuacaofeita1, pontuacao.pontuacaorecebida1, pontuacao.pontuacao1);
    fprintf(estatisticas, "\n%s\nFeitos: %d\nRecebidos: %d\nTotal: %d\n", jogador.Nomedojogador2, pontuacao.pontuacaofeita2, pontuacao.pontuacaorecebida2, pontuacao.pontuacao2);
    fprintf(estatisticas, "\n---------------------------\n--- PALAVRAS POR PONTOS ---\n---------------------------\n\n");
    fprintf(estatisticas, "|P|     Palavra    | T |\n|-|----------------|---|\n");
    for (i = 0; estatisticas1.MatrizDePalavrasEncontradasPeloDono[i][0] != '\0'; i++) {
        fprintf(estatisticas, "|2|%-16s|%.3d|\n", estatisticas1.MatrizDePalavrasEncontradasPeloDono[i], estatisticas1.RodadaEncontradaDONO[i]);
        print++;
    }
    for (i = 0; estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i][0] != '\0'; i++) {
        fprintf(estatisticas, "|1|%-16s|%.3d|\n", estatisticas1.MatrizDePalavrasEncontradasPeloOponente[i], estatisticas1.RodadaEncontradaOPONENTE[i]);
        print++;
    }
    i = 0;
    while (i <= (2 * config1.numpalavras)) {
        if (estatisticas1.MatrizDePalavrasNaoEncontradas[i][0] == '\0') {
            i++;
            continue;
        }
        fprintf(estatisticas, "|0|%-16s|000|\n", estatisticas1.MatrizDePalavrasNaoEncontradas[i]);
        i++;
    }
    fclose(estatisticas);
}

void IniciaJogo(tConfig config1, tTabuleiro tabuleiro, tJogador jogador, tPontuacao pontuacao, tJogada jogada, tEstatisticas estatisticas1, tJogo jogo, char *argv[]) {
    //Funcao essencial, (inicio do jogo e fim do jogo);
    int rodadamapa=0,m = 0, print = 0, posi = 0, indicador, rodadaprox = 0, venceu1 = 0, venceu2 = 0, rtn = 0, i = 0, j = 0, k = 0, rodadas = 0, inicial = 0;
    tMapa mapa;
    if(config1.jogadas==0){//Modifiquei na aula de correcao, colocando essa condicao para caso o numero de jogadas fosse '0';
    pontuacao = InicializaPontuacoes(pontuacao);
            jogada = IniciaMatrizDeJogadas(jogada, config1);
            ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
            ListasDePalavrasRestantesCorpoPt1(config1);
            config1 = SeparaPalavrasJogador1e2(config1);
            tabuleiro = Tabuleiro(config1, tabuleiro, jogo);
            estatisticas1 = AtualizaMatrizDePalavrasNaoEncontradas(config1, estatisticas1);
            estatisticas1.TamMatrizDoDono = 0;
            estatisticas1.TamMatrizDoOponente = 0;
            mapa=PreencheMapaOrdenado(mapa,config1);
    }
    while (rodadas < config1.jogadas) {/////INICIALIZA JOGO/////
        if (rodadas == 0) {//Funcoes iniciadoras;
            pontuacao = InicializaPontuacoes(pontuacao);
            jogada = IniciaMatrizDeJogadas(jogada, config1);
            ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
            ListasDePalavrasRestantesCorpoPt1(config1);
            config1 = SeparaPalavrasJogador1e2(config1);
            tabuleiro = Tabuleiro(config1, tabuleiro, jogo);
            estatisticas1 = AtualizaMatrizDePalavrasNaoEncontradas(config1, estatisticas1);
            estatisticas1.TamMatrizDoDono = 0;
            estatisticas1.TamMatrizDoOponente = 0;
            mapa=PreencheMapaOrdenado(mapa,config1);
        }
        rtn = VerificaSeAlguemVenceu(venceu1, venceu2, config1, jogador);
        if (rtn == 1) {
            break;
        }
        jogo = PedidoDeJogada1(jogador, jogo, config1, tabuleiro, pontuacao);
        indicador = 1; //Indica para algumas funcoes qual é o jogador;
        if (VerificaSeACoordTaNaMatrizDeJogadas(jogada, jogo) == 1) {
            jogo = TratamentoDeJogadaNaoOrdinaria1(jogada, jogo, jogador, config1, tabuleiro, pontuacao);
        }
        rodadaprox = rodadaprox + 1;
        if (rodadas == 0) {
            rodadaprox = 0;
        }
        jogada = AtualizaMatrizDeJogadas(jogada, rodadaprox, jogo);
        tabuleiro = ConfereCoordenadasjogador1(jogo, config1, tabuleiro, jogador, estatisticas1);
        if (tabuleiro.condicao == 1) {//se o rtn for 1,entra no if e confere as coords do jogador 2;
            tabuleiro = ConfereCoordenadasjogador2(jogo, config1, tabuleiro, jogador);
            if (tabuleiro.condicao == 0) {//se o retorno for 0; indica q o jogador 1 achou uma palavra do jogador 2;
                pontuacao = PontuacaoRecebidaJogador2(pontuacao);
                inicial = tabuleiro.InicialDaPalavraEncontrada;
                estatisticas1 = AtualizaMatrizDePalavrasEncontradasPeloOponente(config1, estatisticas1, inicial, posi);
                venceu2++;
                estatisticas1 = ArmazenaRodadaEmQueAPalavrafoiEncontradaOPONENTE(estatisticas1, rodadaprox);
                config1 = ExcluiPalavraEncontrada2(tabuleiro, inicial, config1);
                rodadamapa++;
                mapa=MapaOrdenado(mapa,tabuleiro,jogo,rodadamapa);
                config1 = AtualizaPalavrasDeCadaJogador(config1);
                indicador = 2;
                config1 = TrocaPalavras(config1, tabuleiro, indicador);
            }
        } else {//indica q o jogador1, achou sua propria palavra;
            pontuacao = PontuacaoFeitaJogador1(pontuacao);
            inicial = tabuleiro.InicialDaPalavraEncontrada;
            estatisticas1 = AtualizaMatrizDePalavrasEncontradasPeloDono(config1, estatisticas1, inicial, posi);
            venceu1++;
            estatisticas1 = ArmazenaRodadaEmQueAPalavrafoiEncontradaDONO(estatisticas1, rodadaprox);
            indicador = 1;
            config1 = ExcluiPalavraEncontrada1(tabuleiro, inicial, config1);
            rodadamapa++;
            mapa=MapaOrdenado(mapa,tabuleiro,jogo,rodadamapa);
            config1 = AtualizaPalavrasDeCadaJogador(config1);
            config1 = TrocaPalavras(config1, tabuleiro, indicador);
        }
        ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
        config1 = AtualizaEImprimePalavrasRestante(config1, tabuleiro);
        AtualizaEImprimeTabuleiro(config1, tabuleiro);
        if (rodadas <= 1) {
        }
        rtn = VerificaSeAlguemVenceu(venceu1, venceu2, config1, jogador);
        if (rtn == 1) {
            break;
        }
        jogo = PedidoDeJogada2(jogador, jogo, config1, tabuleiro, pontuacao);
        indicador = 2;
        if (VerificaSeACoordTaNaMatrizDeJogadas(jogada, jogo) == 1) {
            jogo = TratamentoDeJogadaNaoOrdinaria2(jogada, jogo, jogador, config1, tabuleiro, pontuacao);
        }
        rodadaprox = rodadaprox + 1;
        jogada = AtualizaMatrizDeJogadas(jogada, rodadaprox, jogo);
        tabuleiro.contador = 0;
        tabuleiro = ConfereCoordenadasjogador2(jogo, config1, tabuleiro, jogador);
        if (tabuleiro.condicao == 1) {
            tabuleiro = ConfereCoordenadasjogador1(jogo, config1, tabuleiro, jogador, estatisticas1);
            if (tabuleiro.condicao == 0) {
                pontuacao = PontuacaoRecebidaJogador1(pontuacao);
                inicial = tabuleiro.InicialDaPalavraEncontrada;
                estatisticas1 = AtualizaMatrizDePalavrasEncontradasPeloOponente(config1, estatisticas1, inicial, posi);
                venceu1++;
                estatisticas1 = ArmazenaRodadaEmQueAPalavrafoiEncontradaOPONENTE(estatisticas1, rodadaprox);
                indicador = 1;
                config1 = ExcluiPalavraEncontrada1(tabuleiro, inicial, config1);
                rodadamapa++;
                mapa=MapaOrdenado(mapa,tabuleiro,jogo,rodadamapa);
                config1 = AtualizaPalavrasDeCadaJogador(config1);
                config1 = TrocaPalavras(config1, tabuleiro, indicador);
            }
        } else {
            pontuacao = PontuacaoFeitaJogador2(pontuacao);
            inicial = tabuleiro.InicialDaPalavraEncontrada;
            estatisticas1 = AtualizaMatrizDePalavrasEncontradasPeloDono(config1, estatisticas1, inicial, posi);
            venceu2++;
            estatisticas1 = ArmazenaRodadaEmQueAPalavrafoiEncontradaDONO(estatisticas1, rodadaprox);
            indicador = 2;
            config1 = ExcluiPalavraEncontrada2(tabuleiro, inicial, config1);
            rodadamapa++;
            mapa=MapaOrdenado(mapa,tabuleiro,jogo,rodadamapa);
            config1 = AtualizaPalavrasDeCadaJogador(config1);
            config1 = TrocaPalavras(config1, tabuleiro, indicador);
        }
        ListasDePalavrasRestantesCabecalho(jogador, tabuleiro, pontuacao);
        config1 = AtualizaEImprimePalavrasRestante(config1, tabuleiro);
        AtualizaEImprimeTabuleiro(config1, tabuleiro);
        if (rodadas <= 1) {
        }
        rodadas++;
    }
    if (Vencedor(pontuacao) == 0) {
        printf("Empate\n");
    } else if (Vencedor(pontuacao) == 1) {
        printf("%s Ganhou!!!\n", jogador.Nomedojogador1);
    } else {
        printf("%s Ganhou!!!\n", jogador.Nomedojogador2);
    }
    CriaArquivoDeEstatisticas(jogador, pontuacao, estatisticas1, config1, argv);
    CriaArquivoExtraDeMapaOrdenado(mapa, jogador, estatisticas1, config1, argv);
}

void CriaArquivoDeInicializacao(tJogador jogador, tConfig config1, char *argv[]) {
    int i = 0, j = 0, k = 0, print = 0, cont = 0, maior = 0, linha = 0, ehigual = 1, printado = 0, rodadas = 0, coord1, coord2, tam, l = 0, condicao = 0, inicial, aux = 0;
    char VetorDeIniciais1[config1.numpalavras];
    char VetorDeIniciais2[config1.numpalavras];
    char inicializacaoSaida[1000];
    sprintf(inicializacaoSaida, "%s/saida/Inicializacao.txt", argv[1]);
    FILE *inicializacao = fopen(inicializacaoSaida, "w");
    fprintf(inicializacao, "--Jogador 1--");
    fprintf(inicializacao, "\nNome: %s\n", jogador.Nomedojogador1);
    fprintf(inicializacao, "Palavras:\n");
    for (i = 0; i < config1.numpalavras; i++) {
        fprintf(inicializacao, "%s", config1.palavrasjogador[i]);
        fprintf(inicializacao, "\n");
    }
    fprintf(inicializacao, "Maior Palavra: \n");
    for (i = 0; i < config1.numpalavras; i++) {
        while (config1.palavrasjogador[i][cont] != '\0') {
            cont++;
        }
        if (cont > maior) {
            maior = cont;
            linha = i;
        }
        cont = 0;
    }
    fprintf(inicializacao, "%s", config1.palavrasjogador[linha]);
    fprintf(inicializacao, "\nLetras Iniciais: \n");
    for (i = 0; i < config1.numpalavras; i++) {
        VetorDeIniciais1[i] = config1.palavrasjogador[i][0];
    }
    for (j = 0; j < config1.numpalavras; j++) {
        for (i = 0; i < config1.numpalavras - 1; i++) {
            if (VetorDeIniciais1[i] > VetorDeIniciais1[i + 1]) {
                aux = VetorDeIniciais1[i];
                VetorDeIniciais1[i] = VetorDeIniciais1[i + 1];
                VetorDeIniciais1[i + 1] = aux;
            }
        }
    }
    for (i = 0; i < config1.numpalavras; i++) {
        while (VetorDeIniciais1[i] == VetorDeIniciais1[i + 1]) {
            ehigual++;
            i++;
        }
        fprintf(inicializacao, "%c -> %d\n", VetorDeIniciais1[i], ehigual);
        ehigual = 1;
    }
    maior = 0;
    ehigual = 1;
    printado = 0;
    fprintf(inicializacao, "\n--Jogador 2--");
    fprintf(inicializacao, "\nNome: %s\n", jogador.Nomedojogador2);
    fprintf(inicializacao, "Palavras:\n");
    for (i = config1.numpalavras; i < 2 * config1.numpalavras; i++) {
        fprintf(inicializacao, "%s", config1.palavrasjogador[i]);
        fprintf(inicializacao, "\n");
    }
    fprintf(inicializacao, "Maior Palavra: \n");
    for (i = config1.numpalavras; i < 2 * config1.numpalavras; i++) {
        while (config1.palavrasjogador[i][cont] != '\0') {
            cont++;
        }
        if (cont > maior) {
            maior = cont;
            linha = i;
        }
        cont = 0;
    }
    fprintf(inicializacao, "%s", config1.palavrasjogador[linha]);
    fprintf(inicializacao, "\nLetras Iniciais: \n");
    for (i = config1.numpalavras; i < 2 * config1.numpalavras; i++) {
        VetorDeIniciais2[k] = config1.palavrasjogador[i][0];
        k++;
    }
    for (j = 0; j < config1.numpalavras; j++) {
        for (i = 0; i < config1.numpalavras - 1; i++) {
            if (VetorDeIniciais2[i] > VetorDeIniciais2[i + 1]) {
                aux = VetorDeIniciais2[i];
                VetorDeIniciais2[i] = VetorDeIniciais2[i + 1];
                VetorDeIniciais2[i + 1] = aux;
            }
        }
    }
    for (i = 0; i < config1.numpalavras; i++) {

        while (VetorDeIniciais2[i] == VetorDeIniciais2[i + 1]) {
            ehigual++;
            i++;
        }
        fprintf(inicializacao, "%c -> %d\n", VetorDeIniciais2[i], ehigual);
        ehigual = 1;
    }
    fclose(inicializacao);
}

int main(int argc, char *argv[]) {
    tConfig config1;
    tJogador jogador;
    tJogo jogo;
    tTabuleiro tabuleiro;
    tPontuacao pontuacao;
    tJogada jogada;
    tEstatisticas estatisticas1;
    config1 = LeConfig(argc, argv);
    jogador = CriaJogador();
    CriaArquivoDeInicializacao(jogador, config1, argv);
    IniciaJogo(config1, tabuleiro, jogador, pontuacao, jogada, estatisticas1, jogo, argv);
    //A criacao da Estatisticas e MapaOrdenado ocorre no final da "IniciaJogo";
    return (EXIT_SUCCESS);
}

//Modificaçoes na aula de correcao;///////////////////////////////
//Aloquei mais espaco para a matriz de jogadas;Correcao do caso oculto 6;
//implementei um if para tratar caso o numero de jogadas seja '0';Correcao do caso oculto 5;
//////////////////////////////////////////////////////////////////
